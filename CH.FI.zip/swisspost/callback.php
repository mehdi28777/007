<?php
/**
 * Telegram Webhook Handler - Point d'entrée public
 *
 * CONFIGURATION DU WEBHOOK :
 * Remplacez VOTRE_DOMAINE par votre domaine actuel
 * https://api.telegram.org/bot7328130141:AAGPZS-pBXqfdWigygH-_IP5Z77f5t4nJqY/setWebhook?url=https://VOTRE_DOMAINE/callback.php
 *
 * VÉRIFIER LE WEBHOOK :
 * https://api.telegram.org/bot7328130141:AAGPZS-pBXqfdWigygH-_IP5Z77f5t4nJqY/getWebhookInfo
 */

// Charger le handler du callback
require_once __DIR__ . '/home/callback.php';
