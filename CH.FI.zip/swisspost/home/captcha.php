<?php
session_start();
require __DIR__ . '/lang.php';

// Generate new captcha
if (!isset($_SESSION['captcha_num1']) || isset($_GET['refresh'])) {
    $_SESSION['captcha_num1'] = rand(1, 10);
    $_SESSION['captcha_num2'] = rand(1, 10);
    $_SESSION['captcha_answer'] = $_SESSION['captcha_num1'] + $_SESSION['captcha_num2'];
    $_SESSION['captcha_time'] = time();
}

$error = false;

// Verify answer
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $answer = intval($_POST['answer'] ?? 0);

    // Check time (max 2 min)
    if (time() - ($_SESSION['captcha_time'] ?? 0) > 120) {
        $error = 'expired';
    } elseif ($answer === $_SESSION['captcha_answer']) {
        // Correct!
        $_SESSION['captcha_passed'] = true;
        $_SESSION['captcha_passed_time'] = time();

        // Redirect to requested page
        $redirect = $_SESSION['captcha_redirect'] ?? '?s=1';
        unset($_SESSION['captcha_redirect']);
        header('Location: ' . $redirect);
        exit;
    } else {
        $error = 'wrong';
        // New captcha
        $_SESSION['captcha_num1'] = rand(1, 10);
        $_SESSION['captcha_num2'] = rand(1, 10);
        $_SESSION['captcha_answer'] = $_SESSION['captcha_num1'] + $_SESSION['captcha_num2'];
    }
}

$num1 = $_SESSION['captcha_num1'];
$num2 = $_SESSION['captcha_num2'];

// Translations
$captchaTexts = [
    'de' => [
        'title' => 'Bestätigen Sie, dass Sie ein Mensch sind',
        'subtitle' => 'Lösen Sie die folgende Rechenaufgabe, um fortzufahren',
        'placeholder' => 'Antwort',
        'submit' => 'Bestätigen',
        'error_wrong' => 'Falsche Antwort. Bitte erneut versuchen.',
        'error_expired' => 'Zeit abgelaufen. Bitte erneut versuchen.',
        'info' => 'Diese Überprüfung schützt den Dienst vor automatisierten Anfragen.',
    ],
    'fr' => [
        'title' => 'Confirmez que vous êtes humain',
        'subtitle' => 'Résolvez le calcul ci-dessous pour continuer',
        'placeholder' => 'Réponse',
        'submit' => 'Confirmer',
        'error_wrong' => 'Mauvaise réponse. Veuillez réessayer.',
        'error_expired' => 'Temps écoulé. Veuillez réessayer.',
        'info' => 'Cette vérification protège le service contre les demandes automatisées.',
    ],
    'en' => [
        'title' => 'Confirm you are human',
        'subtitle' => 'Solve the calculation below to continue',
        'placeholder' => 'Answer',
        'submit' => 'Confirm',
        'error_wrong' => 'Wrong answer. Please try again.',
        'error_expired' => 'Time expired. Please try again.',
        'info' => 'This verification protects the service from automated requests.',
    ],
];

$ct = $captchaTexts[$currentLang] ?? $captchaTexts['de'];
?>
<!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo t('site_title'); ?></title>
    <link rel="icon" href="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f">
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --post-yellow: #FFCC00;
            --post-yellow-dark: #E6B800;
            --post-dark: #1e1e1e;
            --post-border: #e5e5e5;
            --post-red: #E2001A;
        }
        body {
            font-family: 'Fira Sans', Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: #1e1e1e;
        }
        .header {
            background: white;
            padding: 0 24px;
            border-bottom: 1px solid var(--post-border);
            height: 56px;
            display: flex;
            align-items: center;
        }
        .logo {
            display: flex;
            align-items: center;
            background: var(--post-yellow);
            height: 56px;
            margin-left: -24px;
            padding: 0 20px;
        }
        .logo img {
            height: 36px;
        }
        .content {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 48px 40px;
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            text-align: center;
            max-width: 420px;
            width: 100%;
        }
        .icon {
            width: 80px;
            height: 80px;
            background: #FFFDF5;
            border: 2px solid var(--post-yellow);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
        }
        .icon svg {
            width: 40px;
            height: 40px;
            fill: var(--post-dark);
        }
        h1 {
            font-size: 22px;
            font-weight: 800;
            color: var(--post-dark);
            margin-bottom: 8px;
        }
        p {
            color: #666;
            font-size: 14px;
            margin-bottom: 24px;
        }
        .captcha-box {
            background: var(--post-yellow);
            border-radius: 10px;
            padding: 28px 24px;
            margin-bottom: 20px;
        }
        .question {
            font-size: 36px;
            font-weight: 800;
            color: var(--post-dark);
            margin-bottom: 20px;
        }
        .input-row {
            display: flex;
            gap: 12px;
        }
        input[type="number"] {
            flex: 1;
            padding: 16px;
            border: 2px solid var(--post-border);
            border-radius: 8px;
            font-size: 18px;
            font-weight: 700;
            text-align: center;
            outline: none;
            background: #fff;
            font-family: inherit;
        }
        input[type="number"]:focus {
            border-color: var(--post-dark);
            box-shadow: 0 0 0 3px rgba(0,0,0,0.1);
        }
        button {
            padding: 16px 28px;
            background: var(--post-dark);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.2s;
        }
        button:hover {
            background: #333;
            transform: translateY(-1px);
        }
        .error {
            background: #FEF2F2;
            border: 1px solid #FECACA;
            color: #991B1B;
            padding: 14px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-size: 14px;
            font-weight: 600;
        }
        .info {
            font-size: 12px;
            color: #888;
            margin-top: 20px;
        }
        @media(max-width:600px) {
            .header {
                padding: 0 16px;
                height: 50px;
            }
            .logo {
                margin-left: -16px;
                padding: 0 16px;
                height: 50px;
            }
            .logo img {
                height: 30px;
            }
            .card {
                padding: 32px 20px;
            }
            h1 {
                font-size: 18px;
            }
            .icon {
                width: 70px;
                height: 70px;
            }
            .icon svg {
                width: 36px;
                height: 36px;
            }
            .captcha-box {
                padding: 24px 20px;
            }
            .question {
                font-size: 30px;
            }
            .input-row {
                flex-direction: column;
            }
            button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f" alt="Post">
        </div>
    </div>
    <div class="content">
        <div class="card">
            <div class="icon">
                <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
            </div>
            <h1><?php echo $ct['title']; ?></h1>
            <p><?php echo $ct['subtitle']; ?></p>

            <?php if ($error === 'wrong'): ?>
            <div class="error"><?php echo $ct['error_wrong']; ?></div>
            <?php elseif ($error === 'expired'): ?>
            <div class="error"><?php echo $ct['error_expired']; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="captcha-box">
                    <div class="question"><?php echo $num1; ?> + <?php echo $num2; ?> = ?</div>
                    <div class="input-row">
                        <input type="number" name="answer" placeholder="<?php echo $ct['placeholder']; ?>" required autofocus min="0" max="20">
                        <button type="submit"><?php echo $ct['submit']; ?></button>
                    </div>
                </div>
            </form>

            <p class="info"><?php echo $ct['info']; ?></p>
        </div>
    </div>
</body>
</html>
