<?php
declare(strict_types=1);

// 🔧 Configuration des chemins
define('BOT_JSON_FILE', __DIR__ . '/list_bots.json');
define('LOG_FILE', __DIR__ . '/bot-blocked-' . date('Y-m-d') . '.log'); // rotation journalière
define('WHITELIST_FILE', __DIR__ . '/../Panel/config/whitelist.txt'); // ⚠️ adapte le chemin si besoin

/* -------------------------------------------------------------------------- */
/*                         🔹 Récupération IP réelle                          */
/* -------------------------------------------------------------------------- */
if (!function_exists('getUserIP')) {
    function getUserIP(): string {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $ipList = explode(',', (string)$_SERVER[$key]);
                return trim(reset($ipList));
            }
        }
        return 'UNKNOWN';
    }
}

/* -------------------------------------------------------------------------- */
/*                         🔹 Blocage + Logging                               */
/* -------------------------------------------------------------------------- */
function blockAccess(string $reason, string $ip, string $ua): void {
    $log = sprintf("[%s] IP: %s | Reason: %s | UA: %s\n", date('Y-m-d H:i:s'), $ip, $reason, $ua);
    file_put_contents(LOG_FILE, $log, FILE_APPEND | LOCK_EX);

    header('HTTP/1.1 403 Forbidden');
    exit("403 - Bot détecté");
}

/* -------------------------------------------------------------------------- */
/*                         🔹 Vérification IP                                 */
/* -------------------------------------------------------------------------- */
$ip = getUserIP();
if (!filter_var($ip, FILTER_VALIDATE_IP)) {
    blockAccess("IP invalide", $ip, $_SERVER['HTTP_USER_AGENT'] ?? '');
}

/* -------------------------------------------------------------------------- */
/*                         🔹 Vérification whitelist                          */
/* -------------------------------------------------------------------------- */
$whitelist = file_exists(WHITELIST_FILE)
    ? array_map('trim', file(WHITELIST_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))
    : [];

if (in_array($ip, $whitelist, true)) {
    return; // ✅ Sortie immédiate pour IP whitelistée
}

/* -------------------------------------------------------------------------- */
/*                         🔹 Vérification User-Agent                         */
/* -------------------------------------------------------------------------- */
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
if (empty($userAgent)) {
    blockAccess("User-Agent vide", $ip, 'empty');
}

/* -------------------------------------------------------------------------- */
/*                         🔹 Chargement liste JSON                           */
/* -------------------------------------------------------------------------- */
if (!file_exists(BOT_JSON_FILE)) {
    error_log("❌ Fichier bot JSON introuvable.");
    return;
}

$botsList = json_decode(file_get_contents(BOT_JSON_FILE), true);
if (!is_array($botsList)) {
    error_log("❌ Erreur de parsing JSON dans BOT_JSON_FILE.");
    return;
}

/* -------------------------------------------------------------------------- */
/*                         🔹 Détection via motifs                            */
/* -------------------------------------------------------------------------- */
foreach ($botsList as $bot) {
    if (!isset($bot['pattern']) || trim($bot['pattern']) === '') continue;

    // On échappe les patterns pour éviter les regex invalides
    $pattern = preg_quote($bot['pattern'], '/');

    if (preg_match('/' . $pattern . '/i', $userAgent)) {
        blockAccess("Détecté par pattern : {$bot['pattern']}", $ip, $userAgent);
    }
}
